from datetime import date, datetime, timedelta, timezone

import pytest

from finance_manager.errors import BudgetError, EnrichmentError
from finance_manager.models import (
    Account,
    Direction,
    Instrument,
    SinkingFund,
    Sip,
    SourceChannel,
    Transaction,
    TxnStatus,
)

IST = timezone(timedelta(hours=5, minutes=30))
WHEN = datetime(2026, 3, 14, 19, 30, tzinfo=IST)


def make_txn(**overrides) -> Transaction:
    kwargs = {
        "amount_minor": 10000000,
        "occurred_at": WHEN,
        "direction": Direction.DEBIT,
        "account": Account.HDFC_SALARY,
        "source": SourceChannel.ANDROID_NOTIF,
        "instrument": Instrument.CARD,
        "counterparty": "Emirates",
        "reference": "REF123",
    }
    kwargs.update(overrides)
    return Transaction.from_capture(**kwargs)


class TestTransactionInvariants:
    def test_amount_must_be_positive(self):
        with pytest.raises(ValueError, match="positive"):
            make_txn(amount_minor=0)

    def test_timestamp_must_be_aware(self):
        with pytest.raises(ValueError, match="timezone-aware"):
            make_txn(occurred_at=datetime(2026, 3, 14, 19, 30))

    def test_debit_is_negative_signed(self):
        assert make_txn().signed_minor == -10000000

    def test_credit_is_positive_signed(self):
        assert make_txn(direction=Direction.CREDIT).signed_minor == 10000000

    def test_month_bucket(self):
        assert make_txn().month == "2026-03"

    def test_starts_unenriched(self):
        txn = make_txn()
        assert txn.status is TxnStatus.NEEDS_REVIEW
        assert not txn.is_enriched

    def test_id_is_derived_and_stable(self):
        assert make_txn().txn_id == make_txn().txn_id


class TestEnrichment:
    def test_confirms_with_category(self):
        txn = make_txn().with_enrichment(category="Travel", tags=("trip",), note="Japan")
        assert txn.is_enriched
        assert txn.category == "Travel"

    def test_category_required(self):
        with pytest.raises(EnrichmentError, match="category"):
            make_txn().with_enrichment(category="")

    def test_amortized_requires_a_fund(self):
        """FR-A2: amortization without a fund would hide the spend entirely."""
        with pytest.raises(EnrichmentError, match="sinking fund"):
            make_txn().with_enrichment(category="Travel", amortized=True)

    def test_amortized_with_fund_is_allowed(self):
        txn = make_txn().with_enrichment(category="Travel", sinking_fund="travel", amortized=True)
        assert txn.amortized and txn.sinking_fund == "travel"


class TestSplit:
    def test_lines_sum_exactly(self):
        lines = make_txn().split([("Travel", 6000000), ("Food", 4000000)])
        assert sum(line.amount_minor for line in lines) == 10000000
        assert {line.split_group for line in lines} == {make_txn().txn_id}

    def test_rejects_mismatched_total(self):
        with pytest.raises(EnrichmentError, match="sum to"):
            make_txn().split([("Travel", 6000000), ("Food", 3000000)])

    def test_rejects_single_line(self):
        with pytest.raises(EnrichmentError, match="at least two"):
            make_txn().split([("Travel", 10000000)])

    def test_rejects_non_positive_line(self):
        with pytest.raises(EnrichmentError, match="positive"):
            make_txn().split([("Travel", 10000000), ("Food", 0)])

    def test_line_ids_are_unique(self):
        lines = make_txn().split([("Travel", 5000000), ("Food", 5000000)])
        assert len({line.txn_id for line in lines}) == 2


class TestSinkingFund:
    def fund(self, **overrides) -> SinkingFund:
        kwargs = {
            "fund_id": "travel",
            "name": "Travel Fund",
            "annual_target_minor": 12000000,
            "monthly_allocation_minor": 1000000,
            "period_start": date(2026, 1, 1),
        }
        kwargs.update(overrides)
        return SinkingFund(**kwargs)

    def test_balance_after_lakh_trip(self):
        """Intent §7: ₹1.2L fund minus a ₹1L trip leaves ₹20k."""
        assert self.fund(drawn_minor=10000000).balance_minor == 2000000

    def test_accrual_caps_at_target(self):
        assert self.fund().accrued_minor(24) == 12000000

    def test_accrual_is_linear(self):
        assert self.fund().accrued_minor(3) == 3000000

    def test_negative_months_rejected(self):
        with pytest.raises(BudgetError):
            self.fund().accrued_minor(-1)

    def test_monthly_schedule_reconciles_to_drawn(self):
        """FR-A5: amortized view must total the cash view."""
        fund = self.fund(drawn_minor=10000000)
        assert sum(fund.monthly_schedule()) == fund.drawn_minor

    def test_rejects_negative_target(self):
        with pytest.raises(BudgetError):
            self.fund(annual_target_minor=-1)


class TestSip:
    def test_valid(self):
        sip = Sip("nifty50", "Nifty 50 Index Fund", 500000, 5, Account.HDFC_SALARY)
        assert sip.active

    @pytest.mark.parametrize("day", [0, 29, 31])
    def test_debit_day_bounds(self, day):
        with pytest.raises(BudgetError, match="debit_day"):
            Sip("x", "X", 500000, day, Account.HDFC_SALARY)
