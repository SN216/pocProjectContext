from datetime import UTC, datetime, timedelta, timezone

import pytest

from finance_manager.ids import (
    TIME_BUCKET_SECONDS,
    derive_txn_id,
    is_txn_id,
    normalize_counterparty,
    time_bucket,
)

IST = timezone(timedelta(hours=5, minutes=30))
WHEN = datetime(2026, 3, 14, 19, 30, 0, tzinfo=IST)


def _id(**overrides):
    kwargs = {
        "amount_minor": 10000000,
        "occurred_at": WHEN,
        "account": "HDFC_SALARY",
        "reference": "REF123",
        "counterparty": "Emirates",
    }
    kwargs.update(overrides)
    return derive_txn_id(**kwargs)


class TestDeterminism:
    """FR-S2: the same payment must always yield the same id, on any device."""

    def test_same_inputs_same_id(self):
        assert _id() == _id()

    def test_shape_is_valid(self):
        assert is_txn_id(_id())

    def test_timezone_does_not_matter(self):
        """Two devices in different zones see the same instant."""
        utc_when = WHEN.astimezone(UTC)
        assert _id() == _id(occurred_at=utc_when)

    def test_account_case_and_whitespace_normalized(self):
        assert _id() == _id(account="  hdfc_salary ")

    def test_reference_case_normalized(self):
        assert _id() == _id(reference="ref123")

    def test_small_time_drift_within_bucket_collapses(self):
        """Captures of one payment disagree by seconds; ids must still match."""
        bucket_start = datetime.fromtimestamp(time_bucket(WHEN), tz=UTC)
        a = _id(occurred_at=bucket_start)
        b = _id(occurred_at=bucket_start + timedelta(seconds=TIME_BUCKET_SECONDS - 1))
        assert a == b


class TestDiscrimination:
    @pytest.mark.parametrize(
        "override",
        [
            {"amount_minor": 10000001},
            {"account": "SBI_SAVINGS"},
            {"reference": "REF999"},
            {"occurred_at": WHEN + timedelta(hours=2)},
        ],
    )
    def test_different_inputs_differ(self, override):
        assert _id() != _id(**override)

    def test_counterparty_ignored_when_reference_present(self):
        """The issuer reference is authoritative; merchant text is noise."""
        assert _id() == _id(counterparty="EMIRATES AIRLINE PVT LTD")

    def test_counterparty_matters_without_reference(self):
        a = _id(reference=None, counterparty="Swiggy")
        b = _id(reference=None, counterparty="Zomato")
        assert a != b

    def test_merchant_noise_normalized_without_reference(self):
        a = _id(reference=None, counterparty="Swiggy Pvt Ltd")
        b = _id(reference=None, counterparty="SWIGGY")
        assert a == b


class TestNormalizeCounterparty:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            ("Swiggy Pvt Ltd", "swiggy"),
            ("UPI-ZOMATO@okhdfcbank", "zomato okhdfcbank"),
            ("  ", ""),
            (None, ""),
        ],
    )
    def test_normalization(self, raw, expected):
        assert normalize_counterparty(raw) == expected


class TestTimeBucket:
    def test_requires_timezone(self):
        with pytest.raises(ValueError, match="timezone-aware"):
            time_bucket(datetime(2026, 3, 14, 19, 30))

    def test_floors_to_bucket(self):
        assert time_bucket(WHEN) % TIME_BUCKET_SECONDS == 0


class TestIsTxnId:
    @pytest.mark.parametrize("value", ["", "abc", "I" * 26, 123, "A" * 25])
    def test_rejects_invalid(self, value):
        assert not is_txn_id(value)
