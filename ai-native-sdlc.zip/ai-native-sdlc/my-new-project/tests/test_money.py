from decimal import Decimal

import pytest

from finance_manager.errors import FloatMoneyError, MoneyError
from finance_manager.money import (
    format_inr,
    parse_amount,
    split_evenly,
    to_major,
    to_minor,
)


class TestFloatRejection:
    """NFR-3: money is exact; a float must never enter the pipeline."""

    @pytest.mark.parametrize("value", [1.0, 0.1, 1e3, -2.5])
    def test_to_minor_rejects_float(self, value):
        with pytest.raises(FloatMoneyError):
            to_minor(value)

    def test_rejects_bool(self):
        with pytest.raises(MoneyError):
            to_minor(True)

    def test_split_rejects_float(self):
        with pytest.raises(FloatMoneyError):
            split_evenly(10.0, 2)


class TestToMinor:
    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            (1, 100),
            (0, 0),
            ("10", 1000),
            ("10.50", 1050),
            ("1,00,000.50", 10000050),
            ("1,20,000", 12000000),
            (Decimal("499.99"), 49999),
            ("-250.25", -25025),
        ],
    )
    def test_conversions(self, value, expected):
        assert to_minor(value) == expected

    def test_rejects_sub_paise(self):
        with pytest.raises(MoneyError):
            to_minor("10.005")

    def test_rejects_garbage(self):
        with pytest.raises(MoneyError):
            to_minor("abc")

    def test_rejects_empty(self):
        with pytest.raises(MoneyError):
            to_minor("   ")

    def test_round_trip(self):
        assert to_major(10000050) == Decimal("100000.50")


class TestParseAmount:
    @pytest.mark.parametrize(
        ("text", "expected"),
        [
            ("Rs.1,00,000.00 debited from a/c XX1234", 10000000),
            ("INR 2,500 spent on SBI Elite Card", 250000),
            ("₹499.50 paid to SWIGGY via UPI", 49950),
            ("Your a/c credited by Rs 85000", 8500000),
            ("Rs.10.05 debited", 1005),
        ],
    )
    def test_parses_bank_message_amounts(self, text, expected):
        assert parse_amount(text) == expected

    def test_raises_when_no_amount(self):
        with pytest.raises(MoneyError):
            parse_amount("Your account statement is ready")


class TestFormatInr:
    @pytest.mark.parametrize(
        ("minor", "expected"),
        [
            (10000050, "₹1,00,000.50"),
            (12000000, "₹1,20,000.00"),
            (2000000, "₹20,000.00"),
            (49950, "₹499.50"),
            (5, "₹0.05"),
            (-25025, "-₹250.25"),
        ],
    )
    def test_indian_grouping(self, minor, expected):
        assert format_inr(minor) == expected


class TestSplitEvenly:
    @pytest.mark.parametrize(("minor", "parts"), [(100000, 12), (7, 3), (1, 5), (999999, 7)])
    def test_shares_sum_exactly(self, minor, parts):
        shares = split_evenly(minor, parts)
        assert len(shares) == parts
        assert sum(shares) == minor

    def test_remainder_goes_to_leading_shares(self):
        assert split_evenly(10, 3) == [4, 3, 3]

    def test_negative_sums_exactly(self):
        assert sum(split_evenly(-10, 3)) == -10

    def test_rejects_zero_parts(self):
        with pytest.raises(MoneyError):
            split_evenly(100, 0)

    def test_lakh_over_twelve_months_reconciles(self):
        """Spec FR-A5: the amortized view must total the cash view exactly."""
        assert sum(split_evenly(10000000, 12)) == 10000000
