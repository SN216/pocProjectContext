# Windows shim for the Makefile targets (no `make` on this platform).
# Usage: .\make.ps1 build | test | lint | evals | secrets | all
param(
    [Parameter(Position = 0)]
    [ValidateSet('build', 'test', 'lint', 'evals', 'secrets', 'all')]
    [string]$Target = 'all'
)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$py = 'python'

function Invoke-Step([string]$name, [scriptblock]$body) {
    Write-Host "==> $name" -ForegroundColor Cyan
    & $body
    if ($LASTEXITCODE -ne 0) {
        Write-Host "$name FAILED (exit $LASTEXITCODE)" -ForegroundColor Red
        exit $LASTEXITCODE
    }
}

function Step-Build {
    Invoke-Step 'build' { & $py -m compileall -q src tests }
    Write-Host 'Build succeeded' -ForegroundColor Green
}
function Step-Lint {
    Invoke-Step 'lint' { & $py -m ruff check src tests }
    Invoke-Step 'format' { & $py -m ruff format --check src tests }
}
function Step-Test { Invoke-Step 'test' { & $py -m pytest } }
function Step-Evals { Invoke-Step 'evals' { & $py scripts/run_evals.py --suite evals --min-pass-rate 0.9 } }
function Step-Secrets { Invoke-Step 'secrets' { & $py scripts/scan_secrets.py --staged } }

switch ($Target) {
    'build' { Step-Build }
    'test' { Step-Test }
    'lint' { Step-Lint }
    'evals' { Step-Evals }
    'secrets' { Step-Secrets }
    'all' { Step-Build; Step-Lint; Step-Test; Step-Evals }
}
