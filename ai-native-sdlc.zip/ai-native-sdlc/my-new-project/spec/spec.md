# Finance Manager — Specification

- Derived from: `intent/intent.md` @ commit `066754e` (Status: Accepted)
- Author: SN
- Status: Draft
- Date: 2026-10-16

## Requirements

### Functional

Requirement IDs are referenced by the verification plan and by `plan.md` during Build.

**Capture (FR-C)**

| ID | Requirement |
|---|---|
| FR-C1 | Capture payment events on Android from (a) posted notifications of Google Pay, HDFC, SBI and card apps, and (b) transactional SMS from bank/UPI senders. |
| FR-C2 | Capture payment events on iOS via user-invoked paths only: a Shortcuts "Add Expense" automation, the iOS share sheet, and forwarded bank-alert email parsed server-side. |
| FR-C3 | Parse a raw capture into a normalized `Transaction` (amount, currency, direction, timestamp, account, counterparty/merchant, instrument, raw-source reference). |
| FR-C4 | Deduplicate: multiple raw captures describing one real payment collapse into exactly one ledger row. |
| FR-C5 | Queue captures locally when offline or when the Sheet is unreachable, and sync in order when connectivity returns. |
| FR-C6 | A capture that cannot be parsed is stored as `needs_review` with its raw text, never silently discarded. |

**Enrichment (FR-E)**

| ID | Requirement |
|---|---|
| FR-E1 | Within 30 s of a successful capture, raise a native notification/modal prompting only for missing metadata: category, tag, note, split, sinking-fund attribution. |
| FR-E2 | Support a manual-trigger entry path (quick add) using the same modal, for cash and missed transactions. |
| FR-E3 | Pre-fill category/tag from the merchant→category memory (FR-R4); submit is one tap when confidence is high. |
| FR-E4 | Write the row to the Sheet on submit. If the prompt is dismissed or expires, the row is still written with `status=needs_review`. |
| FR-E5 | A split divides one payment into ≥2 category lines whose amounts sum exactly to the captured amount. |

**Ledger / Google Sheets (FR-S)**

| ID | Requirement |
|---|---|
| FR-S1 | The Google Sheet "Financial Budget Planner" is the system of record. Any local store is a rebuildable cache. |
| FR-S2 | All writes are idempotent, keyed by `txn_id`: re-running a sync never creates a duplicate row. |
| FR-S3 | Manual edits made directly in the Sheet win over cached values on the next reconcile. |
| FR-S4 | The agent never deletes or rewrites user-authored rows or columns outside its own managed column range. |

**Budgets and guardrails (FR-B)**

| ID | Requirement |
|---|---|
| FR-B1 | Evaluate month-to-date spend per category against its monthly budget after every ledger write and on a daily schedule. |
| FR-B2 | Fire a *caution* alert on first crossing of 80% and of 90% of a category budget; fire a *hard limit* alert on first crossing of 100%. |
| FR-B3 | Each alert states category, MTD spend, budget, % used, and days remaining in the month. |
| FR-B4 | Each (category, threshold, month) alert fires at most once — no repeat spam. |
| FR-B5 | Alert routing is configurable per threshold: push, email, or both. |

**Amortization and sinking funds (FR-A)**

| ID | Requirement |
|---|---|
| FR-A1 | Model annual sinking funds with an annual target and a monthly allocation (Travel Fund: ₹1,20,000/yr, ₹10,000/mo). |
| FR-A2 | Classify a qualifying lump-sum expense as amortizable (see "1/5th income rule" below) and draw it against its sinking fund instead of the month's category budget. |
| FR-A3 | An amortized expense must not trigger FR-B2 budget-overrun alerts for the month it was paid. |
| FR-A4 | Maintain and report a running sinking-fund balance (₹1.2L target − ₹1L trip = ₹20k remaining). |
| FR-A5 | Report both views: **cash view** (actual outflow in the month paid) and **amortized view** (expense spread over the fund period). The two must reconcile to the same annual total. |
| FR-A6 | Overdraw of a sinking fund is surfaced as an explicit `fund_overdraw` alert, not as a silent category breach. |

**Reporting (FR-R)**

| ID | Requirement |
|---|---|
| FR-R1 | Generate a monthly source-and-sink report: income by source vs. expense by category and by account, cash and amortized views. |
| FR-R2 | Attach actionable advice: categories that drifted vs. the trailing 3-month mean, largest movers, and concrete suggested adjustments. |
| FR-R3 | Deliver the report by email and write it to a `Reports` tab. |
| FR-R4 | Learn merchant→category mappings from accepted enrichment choices and use them for pre-fill. |
| FR-R5 | Daily digest of `needs_review` rows older than 24 h. |

**Investments / SIP (FR-I)**

| ID | Requirement |
|---|---|
| FR-I1 | Track active SIPs (Nifty 50 Index Fund, Flexi-Cap Fund) with amount, debit day, and account. |
| FR-I2 | Reconcile each expected SIP debit against captured transactions within a ±3-day window. |
| FR-I3 | Raise a UI prompt when a SIP debit is missing, differs in amount, or needs confirmation (step-up, pause, new SIP). |
| FR-I4 | SIP contributions appear in the report as a *sink* distinct from consumption expense. |

### Non-functional

| ID | Requirement |
|---|---|
| NFR-1 | **Capture rate** ≥95% of payments recorded without manual entry on Android. iOS target is explicitly lower (see Gotchas G1). |
| NFR-2 | **Latency** ≤30 s from payment notification to enrichment prompt (p95), on-device path. |
| NFR-3 | **Correctness** zero duplicate ledger rows per real payment; money is exact decimal (`BigDecimal`/`Decimal`, minor units), never float. |
| NFR-4 | **Security** OAuth refresh tokens and API keys live only in Android Keystore / iOS Keychain or an OS-protected secret store; never in the repo, logs, or the Sheet. `scan_secrets.py` must report 0 findings. |
| NFR-5 | **Data minimization** no full PAN, CVV, UPI PIN, net-banking credentials, or OTPs are parsed, stored, or transmitted. Card references are last-4 only. OTP-bearing SMS are dropped before parsing. |
| NFR-6 | **Retention** raw notification/SMS text is retained ≤30 days, then discarded, leaving the parsed record. |
| NFR-7 | **Offline** capture and enrichment work fully offline; sync is eventually consistent. |
| NFR-8 | **Quota** Google Sheets API usage stays within the free tier (60 read + 60 write requests/min/user) via batching and backoff. |
| NFR-9 | **Operability** every sync failure is visible in-app with a retry; nothing fails silently. |
| NFR-10 | **Portability** the ledger is fully reconstructible from the Sheet alone after a device wipe or Android→iOS migration. |
| NFR-11 | **Permissions** sensitive Android permissions are requested with in-context rationale and degrade gracefully when denied. |

## Design

### 1. Architecture

Three tiers, with the Sheet as the system of record:

```
┌──────────────── Device tier ─────────────────┐
│  Android                 iOS                 │
│  ├ NotificationListener  ├ Shortcuts auto.   │
│  ├ SMS BroadcastReceiver ├ Share sheet       │
│  └ Quick-add UI          └ Quick-add UI      │
│            │                     │           │
│            └────► Capture API ◄──┘           │
│                      │                       │
│   Parser → Dedup → Local queue (SQLite/WAL)  │
│                      │                       │
│            Enrichment prompt (OS modal)      │
└──────────────────────┼───────────────────────┘
                       │ (authenticated sync)
┌────────────── Core tier (personal worker) ───┐
│  Sync engine ──► Google Sheets API v4        │
│  Budget engine (thresholds, MTD rollups)     │
│  Amortization engine (sinking funds)         │
│  SIP reconciler                              │
│  Report generator                            │
│  Alert dispatcher (FCM/APNs + SMTP email)    │
│  Email-forward ingest (iOS capture path)     │
└──────────────────────┼───────────────────────┘
                       ▼
        Google Sheet "Financial Budget Planner"
```

The core tier runs as a small scheduled personal worker (single-user, free tier) so that the
monthly report, daily digest, SIP reconciliation, and email-forward ingest still run when the
phone is offline. All device→core traffic is authenticated with a device-bound token; the worker
holds the Google OAuth refresh token.

**Pipeline:** `raw capture → parse → normalize → dedupe → enqueue → enrich → sync → classify
(budget/amortize) → alert/report`. Each stage is pure and independently testable; the queue is
the only mutable boundary.

### 2. Google Sheets API architecture

**Auth.** OAuth 2.0 installed-app flow, scope `https://www.googleapis.com/auth/spreadsheets`
restricted to the single spreadsheet ID. Refresh token stored in the OS secret store (NFR-4);
access tokens are memory-only. No service account — the Sheet is a personal document and a
service account would require sharing it with a non-human principal.

**Tabs and managed ranges.** The agent owns `Transactions`, `SinkingFunds`, `SIPs`, `Reports`,
and `_AgentState`. It reads but never rewrites user-authored tabs. Within `Transactions` it owns
columns A–P; columns beyond P are reserved for the user.

`Transactions` schema:

| Col | Field | Notes |
|---|---|---|
| A | `txn_id` | ULID; idempotency key (FR-S2) |
| B | `posted_at` | ISO-8601 with offset |
| C | `amount_minor` | integer paise, exact (NFR-3) |
| D | `currency` | `INR` |
| E | `direction` | `debit` \| `credit` |
| F | `account` | `HDFC_SALARY` \| `SBI_SAVINGS` \| `SBI_ELITE_CC` \| `HDFC_GOLD_CC` \| `CASH` |
| G | `instrument` | `UPI_GPAY` \| `CARD` \| `NETBANKING` \| `AUTO_DEBIT` \| `CASH` |
| H | `counterparty` | merchant / VPA / payee |
| I | `category` | from the Sheet's category list |
| J | `tags` | comma-separated |
| K | `note` | free text |
| L | `split_group` | shared id across split lines (FR-E5) |
| M | `sinking_fund` | fund id, blank if none |
| N | `amortized` | `TRUE` when charged to a fund, not the month (FR-A2) |
| O | `source` | `android_notif` \| `android_sms` \| `ios_shortcut` \| `ios_email` \| `manual` |
| P | `status` | `confirmed` \| `needs_review` \| `void` |

`SinkingFunds`: `fund_id, name, annual_target_minor, monthly_allocation_minor, period_start,
accrued_minor, drawn_minor, balance_minor`.
`SIPs`: `sip_id, name, amount_minor, debit_day, account, status, last_matched_txn_id`.
`_AgentState`: last sync revision, per-(category, month, threshold) alert flags (FR-B4), and the
merchant→category memory (FR-R4).

**Write protocol.** All writes go through `spreadsheets.values.batchUpdate` in batches of up to
100 rows:

1. Read the `txn_id` column (`values.get` on `Transactions!A:A`) into a membership set, refreshed
   on sync start and on conflict.
2. Filter the outgoing batch against that set — idempotency is enforced client-side because the
   Sheets API has no native upsert (FR-S2).
3. Append new rows with `values.append` (`valueInputOption=RAW`,
   `insertDataOption=INSERT_ROWS`); update existing rows by A1 range resolved from the `txn_id`
   index.
4. Retry on 429/5xx with exponential backoff and full jitter (base 1 s, cap 64 s, max 6 attempts)
   to stay inside the quota (NFR-8).

**Reconciliation (FR-S3).** Each sync cycle calls `spreadsheets.get` with
`includeGridData=false` and compares the Sheet revision against `_AgentState`. If the Sheet
changed, the agent pulls the changed rows and overwrites its cache: **the Sheet always wins.**
The cache is a projection, never an authority (FR-S1, NFR-10).

### 3. Android notification listener vs. iOS Shortcuts

These are not symmetric implementations; they are two capability tiers behind one `CaptureSource`
interface, and the design must not pretend otherwise.

**Android (primary, automatic).**

- `NotificationListenerService` with `BIND_NOTIFICATION_LISTENER_SERVICE`, enabled by the user in
  *Settings → Notification access*. Filters by package allowlist
  (`com.google.android.apps.nbu.paisa.user`, HDFC, SBI, card apps) and extracts
  `EXTRA_TITLE`/`EXTRA_TEXT`/`EXTRA_BIG_TEXT`.
- SMS path: `RECEIVE_SMS`/`READ_SMS` `BroadcastReceiver` filtered to bank/UPI sender IDs
  (`VM-HDFCBK`, `AD-SBIBNK`, …). OTP-bearing messages are dropped before parsing (NFR-5).
  Note: Play Store policy restricts SMS permissions — if this build is not distributed via Play,
  sideload/personal signing is acceptable; if it ever is, the SMS path must be dropped and
  notification capture becomes the sole automatic source (see G2).
- Parsing: per-issuer regex rule pack (amount, direction verb, account last-4, merchant/VPA, ref
  no.), versioned as data so a bank's message-format change is a rules update, not a release.
- Enrichment prompt: high-priority notification with inline `RemoteInput` for the common case,
  expanding to a full modal for split/sinking-fund attribution.
- Reliability: foreground service + `WorkManager` for the sync queue, so OEM battery managers do
  not silently kill capture. Listener rebind is monitored and surfaced (NFR-9).

**iOS (secondary, user-invoked).**

iOS has no public API to read other apps' notifications or SMS. Automatic parity is impossible;
the design accepts a degraded tier rather than an unreliable workaround:

- **Shortcuts automation** — an "Add Expense" shortcut invoked from the share sheet, Back Tap,
  widget, or Lock Screen, calling the app's App Intent with amount/merchant prefilled from the
  shared content.
- **Share sheet** — share a GPay/bank confirmation screen or text into the app; the same parser
  rule pack runs on the shared text.
- **Email forwarding (the only automatic iOS path)** — bank/card alert emails are auto-forwarded
  (a mail rule) to a dedicated ingest address; the core-tier worker parses them and raises a push
  notification that opens the enrichment modal. Latency is minutes, not seconds.
- Enrichment prompt: push notification → notification-content extension with a quick action, or
  app-open modal. Interactive `UNNotificationAction` covers the one-tap case.

| Aspect | Android | iOS |
|---|---|---|
| Automatic capture | Yes (notifications + SMS) | No (email forward only) |
| Trigger latency | seconds | seconds (manual) / minutes (email) |
| User action per txn | confirm only | invoke + confirm |
| Expected capture rate | ≥95% (NFR-1) | ~70% target, manual-dependent |
| Primary risk | OEM battery kills, format drift | user forgets to invoke |

Shared across both: the parser rule pack, the normalized `Transaction` model, dedup, the queue,
the enrichment contract, and the sync engine. Only the capture adapter and the prompt renderer
are platform-specific — this is what makes the Android→iOS transition a capture-tier change, not
a rewrite (NFR-10).

**Deduplication (FR-C4).** One payment commonly yields a GPay notification, a bank SMS, and a
card SMS. Two captures collapse when **all** hold: same `amount_minor`; same `direction`;
`|Δt| ≤ 180 s`; and compatible account (same account, or one side unknown); and either the same
issuer reference number or a normalized-merchant match. Issuer reference number, when present, is
an exact-match override that collapses regardless of the time window. The surviving record keeps
the richest field set and records every contributing source. Canonical `txn_id` = ULID derived
deterministically from `(amount, rounded timestamp bucket, account, ref_no)` so the same payment
captured twice on two devices yields the same id.

### 4. The 1/5th income amortization rule

**Definition.** Let `M` = trailing 3-month mean net monthly income (salary credits to
`HDFC_SALARY` plus other recognized income). A single expense `E` is an **amortization
candidate** when:

```
E ≥ M / 5          (20% of mean monthly net income)
```

This replaces a hard-coded rupee threshold so the rule scales with income. The trailing mean
smooths bonus months; it is recomputed monthly and stored in `_AgentState`.

**Decision flow.**

1. `E < M/5` → ordinary expense. Charged to its category in the month paid. Normal guardrails.
2. `E ≥ M/5` **and** the category maps to a sinking fund → the enrichment prompt offers
   amortization, defaulted **on**, naming the fund and the balance that will remain.
3. `E ≥ M/5` **and** no fund maps → the prompt offers *"create a sinking fund for this?"*. If
   declined, the expense stays in-month and an explicit `large_expense` notice is sent, so a big
   unplanned spend is never silently normalized away.
4. Amortization is always a user-confirmable decision. The rule proposes; the user disposes.
   Nothing is auto-amortized without the prompt (FR-E1).

**Accounting.** Amortized expenses are charged to the fund, not the month:

- Fund accrues `monthly_allocation_minor` each month (Travel Fund ₹10,000/mo → ₹1,20,000/yr).
- On an amortized expense: `drawn_minor += E`; `balance_minor = annual_target − drawn`.
- The expense is excluded from its category's MTD budget consumption (FR-A3), and is instead
  reported as fund drawdown.

**Worked example (from intent §7).** `M = ₹1,00,000` ⇒ threshold `M/5 = ₹20,000`.
A ₹1,00,000 foreign trip in March: `₹1,00,000 ≥ ₹20,000` ✔ and category `Travel` → Travel Fund.
Amortized. Travel Fund: target ₹1,20,000, drawn ₹1,00,000, **balance ₹20,000** for later trips.
March's Travel category shows **no overrun**; March's cash view still shows the ₹1,00,000 outflow.
Amortized view charges ₹10,000/month across the fund year. Both views total ₹1,00,000 for the
year (FR-A5).

**Overdraw (FR-A6).** If a later trip costs ₹30,000 against a ₹20,000 balance, the first ₹20,000
draws the fund and the ₹10,000 excess raises `fund_overdraw`, prompting the user to choose:
charge to the month, raise the annual target, or reallocate from another fund. The agent does not
decide this silently.

**Invariants** (asserted in tests): `drawn ≤ target + explicit_overdraw`; cash-view annual total
== amortized-view annual total; no transaction is counted in both a category budget and a fund
drawdown.

### 5. Alerting

Thresholds 80 / 90 / 100 (%) per category per month, each firing once (FR-B4) via flags in
`_AgentState`. Default routing: 80% → push; 90% → push; 100% → push + email; `fund_overdraw`,
`large_expense`, SIP mismatch, monthly report → email (+push for SIP). Transport: FCM (Android) /
APNs (iOS) and SMTP for email. Alerts contain amounts and category names but no account numbers
or credentials (NFR-5).

## Standards applied

| Standard | How applied |
|---|---|
| **AI-native SDLC hard rule 1–2** | This spec is a gated artifact; Build does not start until it is approved. No deploy/release action is taken by the agent. |
| **Secret handling** (`scripts/scan_secrets.py`, NFR-4) | OAuth client secrets, refresh tokens, FCM/APNs keys and SMTP credentials are OS-keystore- or environment-sourced; `.gitignore`/`.secretsignore` keep local config out of git; the pre-commit hook runs the scanner. |
| **Data minimization / PCI-adjacent hygiene** (NFR-5) | No PAN beyond last-4, no CVV, no PIN, no OTP, no net-banking credentials captured, stored, or sent. |
| **Least privilege** | Sheets OAuth scope limited to spreadsheets, and the token is bound to one spreadsheet id; Android package allowlist, not blanket notification capture. |
| **Platform policy** | Android notification-access and SMS permissions requested with in-context rationale (NFR-11); iOS stays inside public APIs — no attempt to read other apps' notifications (G1). |
| **Exact-money convention** (NFR-3) | Integer minor units end-to-end; no floating-point money anywhere, including the Sheet (`amount_minor`). |
| **Verification before review** (hard rule 3) | Build must pass `make build`/`make test`/`make lint` + secret scan before any PR, per `CLAUDE.md`. |
| **Evals** | Parser, dedup, and amortization cases go into `evals/` and gate via `scripts/run_evals.py` (hard rule 5 evidence). |

## Gotchas

| ID | Concern | Decision / mitigation |
|---|---|---|
| **G1** | **iOS cannot reach Android parity.** No public API reads other apps' notifications or SMS. | Accepted as a product constraint, not a bug. iOS = user-invoked Shortcuts/share-sheet + automatic email-forward ingest. NFR-1 is split per platform. **This is the single biggest expectation gap vs. the intent and needs explicit product-owner acknowledgement.** |
| **G2** | **Android SMS permissions conflict with Play Store policy.** `READ_SMS`/`RECEIVE_SMS` are restricted. | Personal sideloaded build keeps SMS. If distribution is ever required, SMS capture is removed and notification capture is the sole automatic source — capture rate drops. Policy owner: product owner. |
| **G3** | **Bank message formats drift silently.** A reworded SMS/notification silently stops parsing. | Parser rules are versioned data with a confidence score; unparsed captures become `needs_review` (FR-C6) and surface in the daily digest (FR-R5), so drift is visible within 24 h, not at month end. |
| **G4** | **Dedup is the main correctness risk.** Too loose merges two genuine identical payments (two ₹200 coffees, 3 min apart); too tight double-counts. | Reference number is the exact-match override; without it, the 180 s + amount + account window applies. Collisions surface in the enrichment prompt ("is this the same payment?") rather than being auto-merged. Eval cases cover both failure directions. |
| **G5** | **Amortization can hide real overspending.** Normalizing every large expense makes budgets meaningless. | The 1/5th rule only *proposes*; amortization requires a mapped sinking fund and user confirmation. Unmapped large expenses raise `large_expense` instead. Reports always show the cash view alongside the amortized view (FR-A5). |
| **G6** | **Trailing-mean income is unstable early.** Fewer than 3 months of history, or a bonus month, distorts `M`. | Until 3 salary credits exist, fall back to a user-configured monthly income. Use median-of-3 if a month deviates >50% from the other two. Recomputed monthly, stored in `_AgentState` for auditability. |
| **G7** | **Google Sheets is not a transactional database.** Concurrent device + manual edits can race. | Single-writer discipline: only the core-tier sync engine writes. Devices enqueue. Sheet revision is checked before each batch; on conflict the agent re-reads and re-applies (FR-S3). |
| **G8** | **Sheets quota and latency.** Per-write round-trips would blow the 60/min quota. | Batch up to 100 rows per `batchUpdate`, coalesce on a sync tick, exponential backoff with jitter (NFR-8). |
| **G9** | **HDFC Gold Card is applied, not issued.** | Configured as `inactive`; no parser rules enabled until the first real alert is seen. No code path assumes it exists. |
| **G10** | **Email-forward ingest handles financial alerts.** The ingest mailbox is a sensitive sink and a spoofing target. | Dedicated address, sender allowlist + DMARC/SPF verification before parsing, raw mail discarded after parse (NFR-6). |
| **G11** | **Device transition (Android→iOS) must not lose the ledger.** | The Sheet is authoritative; the new device rebuilds its cache from it (NFR-10). Pending unsynced items on the old device must be flushed before migration — a documented migration step, and a pre-migration "unsynced items" check. |
| **G12** | **Alert fatigue.** Per-category thresholds across many categories could emit dozens of alerts. | Once-per-(category, threshold, month) flags (FR-B4), plus a configurable per-month alert cap with overflow rolled into the daily digest. |

## Open questions

Carried from `intent.md`, with the position this spec takes. Items marked **DECISION NEEDED**
must be answered by the product owner before Build.

| # | Question | Position in this spec | Owner / due |
|---|---|---|---|
| 1 | iOS capture mechanism | Shortcuts + share sheet + email-forward; degraded tier accepted (G1) | **DECISION NEEDED** — product owner, before Build |
| 2 | Dedup match key | ref-no override, else amount + account + 180 s + merchant (§3) | Resolved; tune via evals |
| 3 | Sheet contract — may the agent add columns? | Assumes it may add `txn_id`, `sinking_fund`, `amortized`, `source`, `status` in a managed range A–P | **DECISION NEEDED** — needs the real sheet structure, before Build |
| 4 | Amortization trigger | `E ≥ M/5` **and** a mapped sinking fund **and** user confirmation (§4) | Resolved by this spec; confirm the 1/5th definition is "of mean monthly net income" |
| 5 | Sinking-fund overdraw | Explicit `fund_overdraw` prompt: charge to month / raise target / reallocate (FR-A6) | Resolved |
| 6 | Budget source — Sheet or app config? | Assumes budgets live in the Sheet (single source of truth) | **DECISION NEEDED** — product owner |
| 7 | Alert routing and frequency cap | 80/90 push, 100 push+email, once per category/threshold/month (§5, G12) | Resolved; defaults configurable |
| 8 | Where does the agent run? | Device capture + small personal core-tier worker for scheduled jobs (§1) | **DECISION NEEDED** — accept a hosted worker, or on-device only (loses offline-phone scheduling) |
| 9 | Historical backfill | Out of scope for v1; go-live forward only | Resolved (deferred) |
| 10 | Raw text retention | ≤30 days, then discard (NFR-6) | Resolved |
| 11 | *(new)* Which suggested additions from intent §"Suggested additions" enter v1? | This spec includes only merchant→category learning (FR-R4), pending-prompt digest (FR-R5) and refund handling is **not** included | **DECISION NEEDED** — product owner |

## Verification plan

**Unit / property tests**

- Parser rule pack: a fixture corpus of redacted HDFC/SBI/GPay/card SMS and notification texts →
  expected `Transaction` (FR-C3). Includes negative cases: OTP messages, promotional messages,
  balance-only alerts — all must yield no transaction (NFR-5).
- Dedup (FR-C4, G4): both directions — one payment from 3 sources collapses to 1 row; two genuine
  identical payments 3 minutes apart stay 2 rows.
- Money (NFR-3): property test asserting no float path; minor-unit arithmetic round-trips.
- Amortization (§4): threshold boundary `E = M/5 − 1`, `E = M/5`, `E = M/5 + 1`; the ₹1L/₹1.2L
  worked example asserting ₹20,000 balance and no March overrun; overdraw path; invariant
  cash-total == amortized-total over a fund year.
- Income mean (G6): <3 months fallback, bonus-month median behaviour.
- Budget thresholds (FR-B2/B4): crossing 80/90/100 fires once each; re-evaluation does not refire.
- SIP reconciliation (FR-I2): matched, missing, amount-changed within the ±3-day window.

**Integration tests**

- Sheets sync against a scratch spreadsheet: idempotent re-run creates no duplicates (FR-S2);
  manual-edit-wins reconcile (FR-S3); batch of 150 rows splits into 2 batched calls; 429 triggers
  backoff and eventually succeeds (NFR-8).
- Offline → online: captures queued offline sync in order with no loss or duplication (FR-C5).
- Android instrumentation: a synthetic posted notification from an allowlisted package produces an
  enrichment prompt within 30 s (NFR-2); listener rebind after service kill.
- iOS: App Intent / share-sheet entry produces the same normalized `Transaction`; email-forward
  ingest parses an allowlisted sender and rejects a spoofed one (G10).

**Eval suite** (`evals/`, gated by `scripts/run_evals.py`, min pass rate set at Build)

- `parse-*` — real-world message variants per issuer, including drifted formats (G3).
- `dedup-*` — multi-source collapse and near-duplicate separation.
- `amortize-*` — 1/5th rule decisions, fund drawdown, overdraw, cash-vs-amortized reconciliation.
- `advice-*` — monthly report advice quality on fixture ledgers (FR-R2).
- Every production parsing miss becomes a new regression eval case (hard rule 4).

**Manual acceptance (product owner, before the Build gate closes)**

1. Make a ₹1 real UPI payment → row appears in the Sheet with the metadata entered at the prompt.
2. Force a category to 85% → exactly one caution alert, correctly worded.
3. Enter a lump-sum ≥ M/5 against Travel → amortized, fund balance correct, no month overrun.
4. Generate a monthly report → cash and amortized views reconcile.

**Pre-PR gate** (`CLAUDE.md`): `make build`, `make test`, `make lint` all green and
`python3 scripts/scan_secrets.py --staged` reporting 0 findings; evidence pasted into the PR.
