# Finance Manager

- Author: SN (product owner, single-user personal finance)
- Source: Direct product-owner request (Copilot CLI session)
- Status: Accepted
- Date: 2026-10-16

## Problem

Personal spending today is spread across HDFC Bank (salary), SBI Savings, two credit cards
(SBI Elite, HDFC Gold — applied), and Google Pay UPI linked to a Pixel Rupay card, SBI Savings
and the HDFC salary account. Every transaction is recorded by hand into a Google Sheet
("Financial Budget Planner") long after it happens, if at all. Consequences:

- Transactions are missed or entered from memory, so the ledger is incomplete and untrustworthy.
- Category context (tag, note, split, trip) is lost because it is only remembered at the moment of payment.
- Budget overruns are discovered at month end, after the money is spent — there is no 80% warning.
- Recurring SIPs (Nifty 50 Index Fund, Flexi-Cap Fund) are tracked separately from spending, so
  the real income-vs-expense picture is never visible in one place.
- A single lump-sum expense (e.g. ₹1L foreign trip) blows up one month's budget even though it
  is funded by a planned annual sinking fund, making every report after it misleading.

## Proposed outcome

An automated personal finance agent whose system of record is the existing Google Sheet
"Financial Budget Planner". When this is done, all of the following are observably true:

1. **Capture.** A payment made via Google Pay, card, or bank account produces a transaction
   record in the Google Sheet without manual data entry, sourced from OS payment notifications,
   bank/UPI SMS, and banking-app alerts via a native notification listener or webhook/push listener.
2. **Enrich at the moment of spend.** Within seconds of a captured payment (or on manual trigger),
   a native OS notification / UI modal prompts for the missing metadata only — category, tag,
   note, split — and the record is pushed to the Sheet on submit. Unanswered prompts queue as
   "needs review" rather than being dropped.
3. **Cross-platform.** Works on Android (primary today) and on iOS/iPhone (device transition
   expected next month), with the same ledger, same categories, and no re-onboarding. Platform
   capture differences are absorbed behind one capture interface.
4. **Guardrails.** When a monthly category budget crosses the caution threshold (80–90%) a push
   notification and/or personal email is sent; at 100% a hard-limit alert is sent. Each alert
   names the category, amount spent, limit, and days remaining in the month.
5. **Monthly report.** A monthly source-and-sink report (income vs. expense by category and by
   account) is generated automatically, with actionable spending advice (what to cut, what drifted,
   what is on track).
6. **Investments.** Active SIPs (Nifty 50 Index Fund, Flexi-Cap Fund) are tracked alongside
   expenses; when a recurring investment needs manual input or confirmation (amount changed,
   debit not detected, step-up due), a UI notification prompts for it.
7. **Sinking funds and amortization.** Annual sinking funds are first-class (e.g. Travel Fund
   ₹1.2L/year = ₹10k/month allocation). A qualifying lump-sum expense is amortized against its
   sinking fund instead of being charged to one month: a ₹1L trip draws down the ₹1.2L Travel
   Fund, leaves ₹20k available for future trips, and is **not** reported as a monthly budget
   overrun. Reports show both the cash view and the amortized view.

Measurable targets to confirm at Design: ≥95% of payments captured without manual entry;
≤30 seconds from payment to enrichment prompt; zero duplicate ledger rows for the same payment
(e.g. UPI SMS + app notification for one transaction must collapse into one record).

## Affected users and systems

- **User:** a single individual (the product owner); also the approver for every gate.
- **Ledger:** Google Sheets — "Financial Budget Planner" (Google Sheets API, OAuth).
- **Accounts:** HDFC Bank (salary), SBI Savings, SBI Elite Card, HDFC Gold Card (applied, not yet
  active), Google Pay UPI on Pixel Rupay card + SBI Savings + HDFC Salary.
- **Devices/OS:** Android (notification listener / SMS read), iOS (no equivalent notification
  listener — needs an alternative capture path).
- **Channels:** push notifications, personal email (SMTP/transactional provider), native OS
  notification UI.
- **Investments:** SIP providers for Nifty 50 Index Fund and Flexi-Cap Fund (confirmation flow only).

## Constraints

- **Personal financial data.** Credentials, tokens, and transaction data must never be committed
  to the repository and must not leave the user's own accounts/devices. Secret scanning is a
  release blocker.
- **No bank screen-scraping or credential sharing.** Capture is limited to notifications, SMS,
  and official APIs the user is entitled to use. No storing of full card numbers, CVV, UPI PIN,
  or net-banking credentials.
- **Google Sheet is the source of truth.** The agent must fit the existing
  "Financial Budget Planner" structure, not replace it with its own database; any local store is
  a cache/queue that can be rebuilt from the Sheet.
- **Platform capability limits.** Android notification/SMS access requires sensitive runtime
  permissions; iOS does not allow reading other apps' notifications or SMS, so iOS capture must
  use a different, Apple-permissible mechanism (e.g. share-sheet/shortcut, email forwarding,
  manual quick-entry). This constraint shapes the design.
- **Offline tolerance.** Prompts and captures must survive no-network (queue and sync later).
- **Currency:** INR; money handled as exact decimal values, never floating point.
- **Cost:** personal project — prefer free tiers and no paid aggregator subscription.
- **Single user, single ledger.** No multi-tenant or shared-household requirement in v1.

## Out of scope

- Initiating, authorizing, or modifying any payment, transfer, or investment — the agent is
  read-and-record only.
- Tax filing, tax-lot accounting, and capital-gains computation.
- Loan/EMI origination, credit-score tracking, and lender integrations.
- Replacing the Google Sheet with a custom database or dashboard product.
- Multi-user, family, or shared-budget features.
- Portfolio valuation / NAV tracking and investment advice (SIP tracking in v1 = contributions
  and confirmations, not returns).
- Automatic receipt/bill OCR.
- HDFC Gold Card flows beyond config until the card is actually issued.

## Open questions

1. **iOS capture:** which Apple-permissible mechanism is acceptable (Shortcuts automation,
   forwarded transaction emails, share sheet, manual quick-add)? This determines whether parity
   with Android is achievable or whether iOS is a degraded-capture platform.
   --  shortcuts automation sounds cool or which ever will be convenient for me to integrate
2. **Deduplication rule:** when one payment produces both an SMS and an app notification, what is
   the authoritative match key (amount + account + timestamp window + merchant)?
   -- yes
3. **Sheet contract:** what are the exact tabs, columns, and category list in "Financial Budget
   Planner" today, and may the agent add columns (e.g. `sinking_fund`, `amortized_from`,
   `source`, `txn_id`) or must it fit the current schema?
   -- figure that out using my finance budget planner excel sheet (attachment)
4. **Amortization trigger:** what qualifies an expense as amortizable — amount threshold, an
   explicit category→sinking-fund mapping, or a choice made in the enrichment prompt?
   -- amortizable amount: 1/5th of the monthly income at a single transaction or 90% spent react on that category or subcategory in that month
5. **Sinking fund overdraw:** if a trip costs ₹1.5L against a ₹1.2L fund, is the ₹30k excess a
   budget breach, a borrow from next year, or a reallocation from another fund?
   -- reallocation from another fund (prioritically from clubbing fund)
6. **Budget source:** are monthly category budgets defined in the Sheet or in the app config?
  -- both in sheet and app config
7. **Alert routing:** which thresholds go to email vs. push, and what is the maximum alert
   frequency per category per month (to avoid alert fatigue)?
   -- push notifications whenever necessary. monthly report and warnings on email and push both
8. **Where does the agent run:** on-device only, or a personal cloud worker for scheduled jobs
   (monthly report, SIP reminders) when the phone is offline?
   -- no idea. I've claude pro personal (strictly don't use my work account) to work as cloud worker. 
9. **Backfill:** should historical transactions already in the Sheet be normalized/categorized,
   or does the agent only act from go-live forward?
   -- from go-live forward
10. **Retention:** how long may raw notification/SMS text be retained before it is discarded in
    favour of the parsed record?
    -- last 5 transactions

## Suggested additions (proposed by the agent, pending product-owner decision)

Not yet in scope — accept or reject each at the intent gate:

- **Recurring-charge and subscription detection:** flag repeating merchants/amounts (OTT, rent,
  insurance) and warn on a silent price increase or a charge after a cancellation.
- **Salary/income detection and payday sweep:** recognize HDFC salary credits and prompt to
  allocate to savings, SIPs, and sinking funds on payday.
- **Credit-card statement and due-date tracking:** per-card cycle spend, statement date, due date,
  and a "pay in full" reminder — relevant with SBI Elite plus HDFC Gold incoming.
- **Cash-flow forecast:** projected month-end balance from committed recurring debits (SIPs,
  EMIs, subscriptions, sinking-fund allocations) vs. expected income.
- **Merchant→category auto-learning:** remember past choices so the enrichment prompt arrives
  pre-filled and most spends become one-tap.
- **Trip/event grouping:** tag a set of transactions to one event (e.g. "Japan trip") so the
  amortization engine and reporting work on the event, not individual rows.
- **Refund and reversal handling:** match a credit back to its original debit and restore the
  sinking-fund or category balance.
- **Pending-prompt digest:** a daily nudge listing transactions captured but never enriched, so
  the ledger does not silently accumulate "needs review" rows.
- **Sheet-edit reconciliation:** detect manual edits made directly in the Sheet and treat the
  Sheet as the winner, so the two never diverge.
- **Annual review:** year-end source/sink summary, sinking-fund utilization, and next-year
  allocation suggestions.

---

> Format note: keep this file human-readable (the product owner reviews and accepts it) and
> machine-actionable (the agent reads it and produces spec.md from it). Fields are structured
> on purpose; keep each section short and concrete.
