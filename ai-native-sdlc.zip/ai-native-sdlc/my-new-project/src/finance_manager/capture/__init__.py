"""Capture tier: raw signals in, normalized transactions out."""
