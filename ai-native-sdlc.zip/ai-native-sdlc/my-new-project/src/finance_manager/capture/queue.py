"""Durable offline capture queue (spec FR-C5, NFR-6, NFR-7, NFR-9, G11).

The phone is frequently offline, so every capture is written to a local SQLite
database (WAL journal, so an OEM battery-manager kill cannot lose a committed
item) and synced later in FIFO order.

Delivery is lease based: :meth:`CaptureQueue.lease` hands an item to a consumer
and marks it ``in_flight`` with a lease stamp. A consumer that dies never
acknowledges, so :meth:`CaptureQueue.recover_stale` — invoked automatically on
every lease — returns expired leases to ``pending``. That gives at-least-once
delivery at the queue boundary, while the unique dedup key (``txn_id`` for a
transaction, a content hash for a raw capture) makes enqueue idempotent, so the
pair is effectively exactly-once end to end.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, fields
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from pathlib import Path
from types import TracebackType

from ..config import Config
from ..errors import PayloadError, QueueError
from ..models import (
    Account,
    Direction,
    Instrument,
    RawCapture,
    SourceChannel,
    Transaction,
    TxnStatus,
)

DEFAULT_MAX_ATTEMPTS = 5
DEFAULT_LEASE_SECONDS = 300
SCHEMA_VERSION = 1


class QueueStatus(StrEnum):
    PENDING = "pending"
    IN_FLIGHT = "in_flight"
    DONE = "done"
    FAILED = "failed"


class ItemKind(StrEnum):
    RAW = "raw_capture"
    TXN = "transaction"


@dataclass(frozen=True, slots=True)
class QueuedItem:
    """A row of the queue plus its decoded payload."""

    seq: int
    kind: ItemKind
    dedup_key: str
    payload: RawCapture | Transaction | None
    status: QueueStatus
    attempts: int
    enqueued_at: datetime
    updated_at: datetime
    leased_at: datetime | None = None
    last_error: str = ""
    raw_purged: bool = False


_SeqRef = int | QueuedItem | Iterable[int | QueuedItem]
"""Anything that identifies queued rows: a sequence, an item, or a mix of both."""


_SCHEMA = """
CREATE TABLE IF NOT EXISTS queue_items (
    seq         INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT    NOT NULL,
    dedup_key   TEXT    NOT NULL UNIQUE,
    payload     TEXT    NOT NULL,
    raw_text    TEXT,
    raw_at      TEXT,
    raw_purged  INTEGER NOT NULL DEFAULT 0,
    status      TEXT    NOT NULL,
    attempts    INTEGER NOT NULL DEFAULT 0,
    enqueued_at TEXT    NOT NULL,
    updated_at  TEXT    NOT NULL,
    leased_at   TEXT,
    last_error  TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_queue_status_seq ON queue_items (status, seq);
CREATE INDEX IF NOT EXISTS idx_queue_raw_at ON queue_items (raw_at);
"""

_TXN_ENUM_FIELDS: dict[str, type[StrEnum]] = {
    "direction": Direction,
    "account": Account,
    "instrument": Instrument,
    "source": SourceChannel,
    "status": TxnStatus,
}
_TXN_DATETIME_FIELDS = ("occurred_at",)
_TXN_STR_TUPLE_FIELDS = ("tags", "raw_refs")
_TXN_ENUM_TUPLE_FIELDS: dict[str, type[StrEnum]] = {"sources": SourceChannel}


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _iso(moment: datetime) -> str:
    return moment.astimezone(UTC).isoformat()


def _parse_iso(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value)


def _encode_transaction(txn: Transaction) -> dict[str, object]:
    data: dict[str, object] = {}
    for spec in fields(Transaction):
        value = getattr(txn, spec.name)
        if spec.name in _TXN_DATETIME_FIELDS:
            data[spec.name] = value.isoformat()
        elif spec.name in _TXN_ENUM_FIELDS or spec.name in _TXN_ENUM_TUPLE_FIELDS:
            data[spec.name] = (
                [str(member.value) for member in value]
                if spec.name in _TXN_ENUM_TUPLE_FIELDS
                else str(value.value)
            )
        elif spec.name in _TXN_STR_TUPLE_FIELDS:
            data[spec.name] = list(value)
        else:
            data[spec.name] = value
    return data


def _decode_transaction(data: dict[str, object]) -> Transaction:
    kwargs: dict[str, object] = {}
    for spec in fields(Transaction):
        if spec.name not in data:
            raise PayloadError(f"missing transaction field: {spec.name}")
        value = data[spec.name]
        if spec.name in _TXN_DATETIME_FIELDS:
            kwargs[spec.name] = datetime.fromisoformat(str(value))
        elif enum_type := _TXN_ENUM_FIELDS.get(spec.name):
            kwargs[spec.name] = enum_type(value)
        elif member_type := _TXN_ENUM_TUPLE_FIELDS.get(spec.name):
            kwargs[spec.name] = tuple(member_type(member) for member in value)  # type: ignore[union-attr]
        elif spec.name in _TXN_STR_TUPLE_FIELDS:
            kwargs[spec.name] = tuple(value)  # type: ignore[arg-type]
        else:
            kwargs[spec.name] = value
    return Transaction(**kwargs)  # type: ignore[arg-type]


def _encode_raw(capture: RawCapture) -> dict[str, object]:
    """Encode everything but ``text``; the raw text lives in its own column.

    Keeping it out of the payload is what makes the NFR-6 purge a single column
    update that leaves the queued record — and its history — intact.
    """
    return {
        "source": str(capture.source.value),
        "received_at": capture.received_at.isoformat(),
        "package": capture.package,
        "sender": capture.sender,
        "hints": dict(capture.hints),
    }


def _decode_raw(data: dict[str, object], text: str) -> RawCapture:
    try:
        return RawCapture(
            source=SourceChannel(data["source"]),
            received_at=datetime.fromisoformat(str(data["received_at"])),
            text=text,
            package=data.get("package"),  # type: ignore[arg-type]
            sender=data.get("sender"),  # type: ignore[arg-type]
            hints=dict(data.get("hints", {})),  # type: ignore[arg-type]
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise PayloadError(f"corrupt raw capture payload: {exc}") from exc


def raw_dedup_key(capture: RawCapture) -> str:
    """Stable content hash for a raw capture.

    The same notification replayed by a listener rebind hashes identically, so
    it cannot enter the queue twice.
    """
    parts = [
        str(capture.source.value),
        _iso(capture.received_at),
        capture.text,
        capture.package or "",
        capture.sender or "",
        json.dumps(dict(sorted(capture.hints.items())), sort_keys=True, ensure_ascii=False),
    ]
    digest = hashlib.blake2b("\x1f".join(parts).encode("utf-8"), digest_size=16).hexdigest()
    return f"raw:{digest}"


def dedup_key_for(item: RawCapture | Transaction) -> str:
    if isinstance(item, Transaction):
        return f"txn:{item.txn_id}"
    if isinstance(item, RawCapture):
        return raw_dedup_key(item)
    raise QueueError(f"cannot queue unsupported item type: {type(item).__name__}")


class CaptureQueue:
    """A crash-safe, FIFO, idempotent on-device queue."""

    def __init__(
        self,
        path: str | Path = ":memory:",
        *,
        max_attempts: int = DEFAULT_MAX_ATTEMPTS,
        lease_seconds: int = DEFAULT_LEASE_SECONDS,
        raw_retention_days: int = 30,
    ) -> None:
        if max_attempts < 1:
            raise QueueError("max_attempts must be >= 1")
        if lease_seconds < 0:
            raise QueueError("lease_seconds cannot be negative")
        self.path = str(path)
        self.max_attempts = max_attempts
        self.lease_seconds = lease_seconds
        self.raw_retention_days = raw_retention_days
        self._lock = threading.RLock()
        self._closed = False
        if self.path not in (":memory:", ""):
            parent = Path(self.path).expanduser().parent
            if str(parent):
                parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path, check_same_thread=False, timeout=30.0)
        self._conn.row_factory = sqlite3.Row
        self._conn.isolation_level = None
        self._init_db()

    @classmethod
    def from_config(cls, config: Config, **kwargs: object) -> CaptureQueue:
        return cls(
            config.queue_path,
            raw_retention_days=config.capture.raw_retention_days,
            **kwargs,  # type: ignore[arg-type]
        )

    def _init_db(self) -> None:
        with self._lock:
            if self.path != ":memory:":
                self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=FULL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.executescript(_SCHEMA)
            self._conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")

    @property
    def journal_mode(self) -> str:
        with self._lock:
            return str(self._conn.execute("PRAGMA journal_mode").fetchone()[0])

    def __enter__(self) -> CaptureQueue:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        with self._lock:
            if not self._closed:
                self._conn.close()
                self._closed = True

    def _require_open(self) -> None:
        if self._closed:
            raise QueueError("queue is closed")

    def enqueue(self, item: RawCapture | Transaction, *, now: datetime | None = None) -> bool:
        """Queue an item. Returns ``True`` when it was newly queued.

        Re-enqueuing the same ``txn_id`` (or the same raw content) is a no-op,
        so retries and double captures cannot duplicate work (FR-C4/FR-S2).
        """
        self._require_open()
        key = dedup_key_for(item)
        stamp = _iso(now or _utc_now())
        if isinstance(item, Transaction):
            kind = ItemKind.TXN
            payload = json.dumps(_encode_transaction(item), ensure_ascii=False)
            raw_text: str | None = None
            raw_at: str | None = None
        else:
            kind = ItemKind.RAW
            payload = json.dumps(_encode_raw(item), ensure_ascii=False)
            raw_text = item.text
            raw_at = _iso(item.received_at)
        with self._lock, self._transaction() as conn:
            cursor = conn.execute(
                """
                INSERT OR IGNORE INTO queue_items
                    (kind, dedup_key, payload, raw_text, raw_at, status,
                     attempts, enqueued_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)
                """,
                (
                    str(kind.value),
                    key,
                    payload,
                    raw_text,
                    raw_at,
                    str(QueueStatus.PENDING.value),
                    stamp,
                    stamp,
                ),
            )
            return cursor.rowcount == 1

    def enqueue_many(self, items: Iterable[RawCapture | Transaction]) -> int:
        return sum(1 for item in items if self.enqueue(item))

    def lease(self, limit: int = 10, *, now: datetime | None = None) -> list[QueuedItem]:
        """Claim up to ``limit`` pending items in FIFO order, marking them in_flight."""
        self._require_open()
        if limit <= 0:
            return []
        moment = now or _utc_now()
        self.recover_stale(timedelta(seconds=self.lease_seconds), now=moment)
        stamp = _iso(moment)
        with self._lock, self._transaction() as conn:
            rows = conn.execute(
                """
                SELECT * FROM queue_items
                WHERE status = ?
                ORDER BY seq ASC
                LIMIT ?
                """,
                (str(QueueStatus.PENDING.value), limit),
            ).fetchall()
            if not rows:
                return []
            seqs = [int(row["seq"]) for row in rows]
            placeholders = ",".join("?" for _ in seqs)
            conn.execute(
                f"""
                UPDATE queue_items
                SET status = ?, leased_at = ?, updated_at = ?
                WHERE seq IN ({placeholders})
                """,
                (str(QueueStatus.IN_FLIGHT.value), stamp, stamp, *seqs),
            )
            leased: list[QueuedItem] = []
            for row in rows:
                item = self._row_to_item(
                    row,
                    status=QueueStatus.IN_FLIGHT,
                    leased_at=moment.astimezone(UTC),
                    conn=conn,
                )
                if item is not None:
                    leased.append(item)
            return leased

    def drain(self, limit: int = 100, *, now: datetime | None = None) -> list[QueuedItem]:
        """Alias of :meth:`lease` for the sync engine's batch vocabulary."""
        return self.lease(limit, now=now)

    def ack(self, ids: _SeqRef, *, now: datetime | None = None) -> int:
        """Mark items done. Returns the number of rows affected."""
        self._require_open()
        seqs = _as_seqs(ids)
        if not seqs:
            return 0
        stamp = _iso(now or _utc_now())
        placeholders = ",".join("?" for _ in seqs)
        with self._lock, self._transaction() as conn:
            cursor = conn.execute(
                f"""
                UPDATE queue_items
                SET status = ?, leased_at = NULL, updated_at = ?, last_error = ''
                WHERE seq IN ({placeholders}) AND status != ?
                """,
                (
                    str(QueueStatus.DONE.value),
                    stamp,
                    *seqs,
                    str(QueueStatus.DONE.value),
                ),
            )
            return cursor.rowcount

    def nack(
        self,
        ids: _SeqRef,
        *,
        error: str = "",
        now: datetime | None = None,
    ) -> list[QueuedItem]:
        """Return items to ``pending`` and count the attempt.

        Items that exhaust ``max_attempts`` become ``failed`` and are returned,
        so the caller can surface them instead of losing them (NFR-9).
        """
        self._require_open()
        seqs = _as_seqs(ids)
        if not seqs:
            return []
        stamp = _iso(now or _utc_now())
        placeholders = ",".join("?" for _ in seqs)
        with self._lock, self._transaction() as conn:
            conn.execute(
                f"""
                UPDATE queue_items
                SET attempts = attempts + 1,
                    leased_at = NULL,
                    updated_at = ?,
                    last_error = ?,
                    status = CASE
                        WHEN attempts + 1 >= ? THEN ?
                        ELSE ?
                    END
                WHERE seq IN ({placeholders})
                """,
                (
                    stamp,
                    error,
                    self.max_attempts,
                    str(QueueStatus.FAILED.value),
                    str(QueueStatus.PENDING.value),
                    *seqs,
                ),
            )
            rows = conn.execute(
                f"""
                SELECT * FROM queue_items
                WHERE seq IN ({placeholders}) AND status = ?
                ORDER BY seq ASC
                """,
                (*seqs, str(QueueStatus.FAILED.value)),
            ).fetchall()
            return [item for row in rows if (item := self._row_to_item(row, conn=conn))]

    def fail(self, ids: _SeqRef, *, error: str = "", now: datetime | None = None) -> int:
        """Move items straight to ``failed`` without further retries."""
        self._require_open()
        seqs = _as_seqs(ids)
        if not seqs:
            return 0
        stamp = _iso(now or _utc_now())
        placeholders = ",".join("?" for _ in seqs)
        with self._lock, self._transaction() as conn:
            cursor = conn.execute(
                f"""
                UPDATE queue_items
                SET status = ?, leased_at = NULL, updated_at = ?, last_error = ?
                WHERE seq IN ({placeholders})
                """,
                (str(QueueStatus.FAILED.value), stamp, error, *seqs),
            )
            return cursor.rowcount

    def retry_failed(self, ids: _SeqRef | None = None) -> int:
        """Reset failed items to pending (the in-app retry behind NFR-9)."""
        self._require_open()
        stamp = _iso(_utc_now())
        with self._lock, self._transaction() as conn:
            if ids is None:
                cursor = conn.execute(
                    """
                    UPDATE queue_items
                    SET status = ?, attempts = 0, leased_at = NULL, updated_at = ?
                    WHERE status = ?
                    """,
                    (str(QueueStatus.PENDING.value), stamp, str(QueueStatus.FAILED.value)),
                )
                return cursor.rowcount
            seqs = _as_seqs(ids)
            if not seqs:
                return 0
            placeholders = ",".join("?" for _ in seqs)
            cursor = conn.execute(
                f"""
                UPDATE queue_items
                SET status = ?, attempts = 0, leased_at = NULL, updated_at = ?
                WHERE seq IN ({placeholders}) AND status = ?
                """,
                (
                    str(QueueStatus.PENDING.value),
                    stamp,
                    *seqs,
                    str(QueueStatus.FAILED.value),
                ),
            )
            return cursor.rowcount

    def recover_stale(
        self,
        older_than: timedelta | int | float | None = None,
        *,
        now: datetime | None = None,
    ) -> list[int]:
        """Return expired ``in_flight`` leases to ``pending``.

        This is the crash-recovery path: a process killed mid-sync leaves rows
        leased forever, and nothing else would ever hand them out again.
        """
        self._require_open()
        if older_than is None:
            older_than = timedelta(seconds=self.lease_seconds)
        elif not isinstance(older_than, timedelta):
            older_than = timedelta(seconds=float(older_than))
        moment = now or _utc_now()
        cutoff = _iso(moment - older_than)
        stamp = _iso(moment)
        with self._lock, self._transaction() as conn:
            rows = conn.execute(
                """
                SELECT seq FROM queue_items
                WHERE status = ? AND leased_at IS NOT NULL AND leased_at <= ?
                ORDER BY seq ASC
                """,
                (str(QueueStatus.IN_FLIGHT.value), cutoff),
            ).fetchall()
            seqs = [int(row["seq"]) for row in rows]
            if not seqs:
                return []
            placeholders = ",".join("?" for _ in seqs)
            conn.execute(
                f"""
                UPDATE queue_items
                SET status = ?, leased_at = NULL, updated_at = ?
                WHERE seq IN ({placeholders})
                """,
                (str(QueueStatus.PENDING.value), stamp, *seqs),
            )
            return seqs

    def purge_raw(
        self,
        older_than_days: int | None = None,
        *,
        now: datetime | None = None,
    ) -> int:
        """Discard raw notification/SMS text past the retention window (NFR-6).

        The queue row itself survives — only the text is dropped — so audit and
        sync state are untouched.
        """
        self._require_open()
        days = self.raw_retention_days if older_than_days is None else older_than_days
        if days < 0:
            raise QueueError("older_than_days cannot be negative")
        moment = now or _utc_now()
        cutoff = _iso(moment - timedelta(days=days))
        stamp = _iso(moment)
        with self._lock, self._transaction() as conn:
            cursor = conn.execute(
                """
                UPDATE queue_items
                SET raw_text = NULL, raw_purged = 1, updated_at = ?
                WHERE kind = ? AND raw_purged = 0 AND raw_at IS NOT NULL AND raw_at < ?
                """,
                (stamp, str(ItemKind.RAW.value), cutoff),
            )
            return cursor.rowcount

    def get(self, seq: int) -> QueuedItem | None:
        self._require_open()
        with self._lock:
            row = self._conn.execute("SELECT * FROM queue_items WHERE seq = ?", (seq,)).fetchone()
            return None if row is None else self._row_to_item(row, conn=self._conn)

    def items(self, status: QueueStatus | None = None) -> list[QueuedItem]:
        self._require_open()
        with self._lock:
            if status is None:
                rows = self._conn.execute("SELECT * FROM queue_items ORDER BY seq ASC").fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM queue_items WHERE status = ? ORDER BY seq ASC",
                    (str(status.value),),
                ).fetchall()
            return [item for row in rows if (item := self._row_to_item(row, conn=self._conn))]

    def pending_count(self) -> int:
        return self._count(QueueStatus.PENDING)

    def in_flight_count(self) -> int:
        return self._count(QueueStatus.IN_FLIGHT)

    def failed_items(self) -> list[QueuedItem]:
        return self.items(QueueStatus.FAILED)

    def stats(self) -> dict[str, object]:
        """Counters for the pre-migration "unsynced items" check (spec G11)."""
        self._require_open()
        with self._lock:
            rows = self._conn.execute(
                "SELECT status, COUNT(*) AS n FROM queue_items GROUP BY status"
            ).fetchall()
            counts = {str(status.value): 0 for status in QueueStatus}
            for row in rows:
                counts[str(row["status"])] = int(row["n"])
            oldest = self._conn.execute(
                "SELECT MIN(enqueued_at) AS oldest FROM queue_items WHERE status IN (?, ?, ?)",
                (
                    str(QueueStatus.PENDING.value),
                    str(QueueStatus.IN_FLIGHT.value),
                    str(QueueStatus.FAILED.value),
                ),
            ).fetchone()["oldest"]
        unsynced = (
            counts[QueueStatus.PENDING.value]
            + counts[QueueStatus.IN_FLIGHT.value]
            + counts[QueueStatus.FAILED.value]
        )
        return {
            **counts,
            "total": sum(counts.values()),
            "unsynced": unsynced,
            "safe_to_migrate": unsynced == 0,
            "oldest_unsynced_at": _parse_iso(oldest),
        }

    def _count(self, status: QueueStatus) -> int:
        self._require_open()
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) AS n FROM queue_items WHERE status = ?",
                (str(status.value),),
            ).fetchone()
            return int(row["n"])

    def _transaction(self) -> _Transaction:
        return _Transaction(self._conn)

    def _row_to_item(
        self,
        row: sqlite3.Row,
        *,
        status: QueueStatus | None = None,
        leased_at: datetime | None = None,
        conn: sqlite3.Connection | None = None,
    ) -> QueuedItem | None:
        seq = int(row["seq"])
        try:
            kind = ItemKind(row["kind"])
            data = json.loads(row["payload"])
            if not isinstance(data, dict):
                raise PayloadError("payload is not an object")
            payload: RawCapture | Transaction | None
            if kind is ItemKind.TXN:
                payload = _decode_transaction(data)
            else:
                payload = _decode_raw(data, row["raw_text"] or "")
        except (PayloadError, ValueError, TypeError) as exc:
            # A corrupt row must surface as a visible failure, never vanish.
            self._quarantine(seq, f"{type(exc).__name__}: {exc}", conn=conn)
            return None
        return QueuedItem(
            seq=seq,
            kind=kind,
            dedup_key=str(row["dedup_key"]),
            payload=payload,
            status=QueueStatus(row["status"]) if status is None else status,
            attempts=int(row["attempts"]),
            enqueued_at=_parse_iso(row["enqueued_at"]),  # type: ignore[arg-type]
            updated_at=_parse_iso(row["updated_at"]),  # type: ignore[arg-type]
            leased_at=_parse_iso(row["leased_at"]) if leased_at is None else leased_at,
            last_error=str(row["last_error"] or ""),
            raw_purged=bool(row["raw_purged"]),
        )

    def _quarantine(self, seq: int, error: str, *, conn: sqlite3.Connection | None = None) -> None:
        target = conn or self._conn
        target.execute(
            """
            UPDATE queue_items
            SET status = ?, leased_at = NULL, updated_at = ?, last_error = ?
            WHERE seq = ?
            """,
            (str(QueueStatus.FAILED.value), _iso(_utc_now()), error, seq),
        )

    def corrupt_items(self) -> list[int]:
        """Sequences whose stored payload could not be decoded."""
        self._require_open()
        with self._lock:
            rows = self._conn.execute(
                "SELECT seq, payload, kind FROM queue_items ORDER BY seq ASC"
            ).fetchall()
        bad: list[int] = []
        for row in rows:
            try:
                data = json.loads(row["payload"])
                if ItemKind(row["kind"]) is ItemKind.TXN:
                    _decode_transaction(data)
            except (PayloadError, ValueError, TypeError):
                bad.append(int(row["seq"]))
        return bad


class _Transaction:
    """``BEGIN IMMEDIATE`` context manager: writers serialize, readers do not."""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self._conn = conn

    def __enter__(self) -> sqlite3.Connection:
        self._conn.execute("BEGIN IMMEDIATE")
        return self._conn

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if exc_type is None:
            self._conn.execute("COMMIT")
        else:
            self._conn.execute("ROLLBACK")


def _as_seqs(ids: _SeqRef) -> list[int]:
    if isinstance(ids, QueuedItem):
        return [ids.seq]
    if isinstance(ids, int):
        return [ids]
    seqs: list[int] = []
    for value in ids:
        if isinstance(value, QueuedItem):
            seqs.append(value.seq)
        else:
            seqs.append(int(value))
    return seqs


def unsynced_report(queue: CaptureQueue) -> str:
    """Human-readable pre-migration check (spec G11)."""
    stats = queue.stats()
    if stats["safe_to_migrate"]:
        return "No unsynced items: safe to migrate."
    return (
        f"{stats['unsynced']} unsynced item(s): "
        f"{stats[QueueStatus.PENDING.value]} pending, "
        f"{stats[QueueStatus.IN_FLIGHT.value]} in flight, "
        f"{stats[QueueStatus.FAILED.value]} failed. "
        "Flush the queue before migrating."
    )


__all__: Sequence[str] = (
    "CaptureQueue",
    "ItemKind",
    "QueueStatus",
    "QueuedItem",
    "dedup_key_for",
    "raw_dedup_key",
    "unsynced_report",
)
