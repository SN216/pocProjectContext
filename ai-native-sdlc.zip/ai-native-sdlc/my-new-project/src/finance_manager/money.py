"""Exact money handling.

Money is integer **minor units** (paise) everywhere in this codebase. Floats are
rejected at the boundary rather than rounded, because a silent 0.01 drift in a
ledger is indistinguishable from a parsing bug (spec NFR-3).

The only accepted inputs are ``int``, ``Decimal``, and ``str``. ``bool`` is
rejected too: it is an ``int`` subclass and ``True`` is not an amount.
"""

from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

from .errors import FloatMoneyError, MoneyError

MINOR_UNITS_PER_MAJOR = 100
"""Paise per rupee."""

DEFAULT_CURRENCY = "INR"

_AMOUNT_RE = re.compile(
    r"""
    (?:(?P<sign>-)\s*)?
    (?:(?:rs|inr|₹)\.?\s*)?          # optional currency marker
    (?P<digits>\d[\d,]*)             # integer part, may carry Indian grouping
    (?:\.(?P<frac>\d{1,2}))?         # optional paise
    """,
    re.IGNORECASE | re.VERBOSE,
)


def _reject_float(value: object) -> None:
    if isinstance(value, float):
        raise FloatMoneyError(
            f"float is not an accepted money type: {value!r}. Use int minor units, Decimal, or str."
        )


def to_minor(value: int | str | Decimal) -> int:
    """Convert a major-unit amount to exact minor units.

    >>> to_minor("1,00,000.50")
    10000050
    >>> to_minor(Decimal("10"))
    1000

    Raises ``FloatMoneyError`` on float input and ``MoneyError`` on anything
    that is not a well-formed amount or carries sub-paise precision.
    """
    _reject_float(value)
    if isinstance(value, bool):
        raise MoneyError(f"bool is not an amount: {value!r}")
    if isinstance(value, int):
        return value * MINOR_UNITS_PER_MAJOR
    if isinstance(value, Decimal):
        dec = value
    elif isinstance(value, str):
        cleaned = value.replace(",", "").strip()
        if not cleaned:
            raise MoneyError("empty amount string")
        try:
            dec = Decimal(cleaned)
        except InvalidOperation as exc:
            raise MoneyError(f"not a valid amount: {value!r}") from exc
    else:
        raise MoneyError(f"unsupported money type: {type(value).__name__}")

    if not dec.is_finite():
        raise MoneyError(f"non-finite amount: {value!r}")
    scaled = dec * MINOR_UNITS_PER_MAJOR
    if scaled != scaled.to_integral_value():
        raise MoneyError(f"amount has sub-paise precision: {value!r}")
    return int(scaled)


def to_major(minor: int) -> Decimal:
    """Convert minor units back to an exact ``Decimal`` major amount."""
    require_minor(minor)
    return Decimal(minor) / Decimal(MINOR_UNITS_PER_MAJOR)


def require_minor(minor: object) -> int:
    """Assert that ``minor`` is a valid minor-unit integer and return it."""
    _reject_float(minor)
    if isinstance(minor, bool) or not isinstance(minor, int):
        raise MoneyError(f"minor units must be int, got {type(minor).__name__}")
    return minor


def parse_amount(text: str) -> int:
    """Extract the first rupee amount from free text, as minor units.

    Handles the Indian grouping used in bank messages ("Rs.1,00,000.00",
    "INR 2,500", "₹499.50"). Raises ``MoneyError`` when no amount is present.
    """
    if not isinstance(text, str):
        raise MoneyError(f"expected text, got {type(text).__name__}")
    match = _AMOUNT_RE.search(text)
    if match is None:
        raise MoneyError(f"no amount found in: {text!r}")
    digits = match.group("digits").replace(",", "")
    frac = match.group("frac") or "0"
    minor = int(digits) * MINOR_UNITS_PER_MAJOR + int(frac.ljust(2, "0"))
    return -minor if match.group("sign") else minor


def format_inr(minor: int, *, symbol: str = "₹") -> str:
    """Format minor units using Indian digit grouping.

    >>> format_inr(10000050)
    '₹1,00,000.50'
    """
    require_minor(minor)
    sign = "-" if minor < 0 else ""
    whole, paise = divmod(abs(minor), MINOR_UNITS_PER_MAJOR)
    digits = str(whole)
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        grouped = ",".join([*groups, tail])
    else:
        grouped = digits
    return f"{sign}{symbol}{grouped}.{paise:02d}"


def split_evenly(minor: int, parts: int) -> list[int]:
    """Split minor units into ``parts`` shares that sum **exactly** to the input.

    The remainder is distributed one paisa at a time to the leading shares, so
    no paisa is created or lost (spec FR-E5, FR-A5).
    """
    require_minor(minor)
    if parts < 1:
        raise MoneyError("parts must be >= 1")
    sign = -1 if minor < 0 else 1
    base, remainder = divmod(abs(minor), parts)
    shares = [base + (1 if i < remainder else 0) for i in range(parts)]
    return [sign * share for share in shares]
