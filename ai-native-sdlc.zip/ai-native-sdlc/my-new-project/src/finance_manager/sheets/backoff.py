"""Exponential backoff with full jitter for the Sheets API (spec NFR-8).

Base 1 s, cap 64 s, at most 6 attempts. The delay computation is a pure
function of the attempt number and an injected random source, so the retry
policy is tested deterministically and without ever sleeping.
"""

from __future__ import annotations

import random
import time
from collections.abc import Callable, Iterable
from typing import TypeVar

from ..errors import QuotaError, SheetsError

BASE_DELAY_SECONDS = 1.0
MAX_DELAY_SECONDS = 64.0
MAX_ATTEMPTS = 6

RETRYABLE_STATUS = frozenset({408, 429, 500, 502, 503, 504})

T = TypeVar("T")


class TransportError(SheetsError):
    """A transport-level failure carrying an HTTP-ish status code."""

    def __init__(self, status: int, message: str = "") -> None:
        super().__init__(message or f"sheets transport failed with status {status}")
        self.status = status


def delay_ceiling(attempt: int) -> float:
    """Upper bound of the jitter window for a 1-based ``attempt``."""
    if attempt < 1:
        raise ValueError("attempt must be >= 1")
    return min(MAX_DELAY_SECONDS, BASE_DELAY_SECONDS * (2 ** (attempt - 1)))


def compute_delay(attempt: int, random_fn: Callable[[], float] = random.random) -> float:
    """Full-jitter delay: uniform in ``[0, ceiling]`` for this attempt."""
    draw = random_fn()
    if not 0.0 <= draw <= 1.0:
        raise ValueError("random_fn must return a value in [0, 1]")
    return delay_ceiling(attempt) * draw


def delays(
    max_attempts: int = MAX_ATTEMPTS,
    random_fn: Callable[[], float] = random.random,
) -> list[float]:
    """The full sequence of sleeps between ``max_attempts`` tries."""
    if max_attempts < 1:
        raise ValueError("max_attempts must be >= 1")
    return [compute_delay(attempt, random_fn) for attempt in range(1, max_attempts)]


def status_of(exc: BaseException) -> int | None:
    """Best-effort extraction of an HTTP status from a transport exception."""
    for attribute in ("status", "status_code", "code"):
        value = getattr(exc, attribute, None)
        if isinstance(value, int):
            return value
    response = getattr(exc, "resp", None)
    value = getattr(response, "status", None)
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def is_retryable(exc: BaseException) -> bool:
    """True for rate-limit and transient server failures only."""
    status = status_of(exc)
    return status is not None and status in RETRYABLE_STATUS


def retry(
    fn: Callable[[], T],
    *,
    sleep_fn: Callable[[float], None] = time.sleep,
    random_fn: Callable[[], float] = random.random,
    max_attempts: int = MAX_ATTEMPTS,
    retryable: Callable[[BaseException], bool] = is_retryable,
    on_retry: Callable[[int, float, BaseException], None] | None = None,
) -> T:
    """Call ``fn``, retrying transient failures with full-jitter backoff.

    Non-retryable errors propagate untouched; exhausting the attempts raises
    ``QuotaError`` chained to the last transport failure.
    """
    if max_attempts < 1:
        raise ValueError("max_attempts must be >= 1")
    last: BaseException | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except Exception as exc:
            if not retryable(exc):
                raise
            last = exc
            if attempt == max_attempts:
                break
            pause = compute_delay(attempt, random_fn)
            if on_retry is not None:
                on_retry(attempt, pause, exc)
            sleep_fn(pause)
    raise QuotaError(
        f"Sheets API gave up after {max_attempts} attempts: {last}"
    ) from last


def total_worst_case(max_attempts: int = MAX_ATTEMPTS) -> float:
    """Worst-case cumulative wait, useful for sizing sync windows."""
    return sum(delay_ceiling(attempt) for attempt in range(1, max_attempts))


def ceilings(max_attempts: int = MAX_ATTEMPTS) -> Iterable[float]:
    return (delay_ceiling(attempt) for attempt in range(1, max_attempts))
