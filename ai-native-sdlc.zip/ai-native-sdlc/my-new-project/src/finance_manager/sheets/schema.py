"""Column detection and row (de)serialization for the Transactions tab.

The user's spreadsheet already exists with headers we do not control, so the
agent *detects* the columns it needs instead of assuming a layout. Two rules
make a wrong mapping impossible rather than unlikely (plan risk #1):

* when two headers match the same logical field the mapping raises
  ``AmbiguousColumnError`` — the agent never guesses;
* a write target is only ever returned for a field that was detected or
  explicitly created, so an unmapped column cannot be written to.

Missing agent columns are appended to the right of every existing user column;
nothing is inserted in the middle and no user column is overwritten (FR-S4).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum

from ..errors import AmbiguousColumnError, SchemaError, UnmappedFieldError
from ..models import Account, Direction, Instrument, SourceChannel, Transaction, TxnStatus
from ..money import DEFAULT_CURRENCY, require_minor


class LogicalField(StrEnum):
    """The fields the agent needs; the Sheet may name them anything."""

    TXN_ID = "txn_id"
    OCCURRED_AT = "occurred_at"
    AMOUNT = "amount"
    DIRECTION = "direction"
    ACCOUNT = "account"
    INSTRUMENT = "instrument"
    COUNTERPARTY = "counterparty"
    CATEGORY = "category"
    TAGS = "tags"
    NOTE = "note"
    SPLIT_GROUP = "split_group"
    SINKING_FUND = "sinking_fund"
    AMORTIZED = "amortized"
    SOURCE = "source"
    STATUS = "status"
    REFERENCE = "reference"


FIELD_ORDER: tuple[LogicalField, ...] = tuple(LogicalField)

REQUIRED_FIELDS: frozenset[LogicalField] = frozenset(
    {
        LogicalField.TXN_ID,
        LogicalField.OCCURRED_AT,
        LogicalField.AMOUNT,
        LogicalField.DIRECTION,
        LogicalField.ACCOUNT,
    }
)

CANONICAL_HEADERS: dict[LogicalField, str] = {
    LogicalField.TXN_ID: "txn_id",
    LogicalField.OCCURRED_AT: "posted_at",
    LogicalField.AMOUNT: "amount_minor",
    LogicalField.DIRECTION: "direction",
    LogicalField.ACCOUNT: "account",
    LogicalField.INSTRUMENT: "instrument",
    LogicalField.COUNTERPARTY: "counterparty",
    LogicalField.CATEGORY: "category",
    LogicalField.TAGS: "tags",
    LogicalField.NOTE: "note",
    LogicalField.SPLIT_GROUP: "split_group",
    LogicalField.SINKING_FUND: "sinking_fund",
    LogicalField.AMORTIZED: "amortized",
    LogicalField.SOURCE: "source",
    LogicalField.STATUS: "status",
    LogicalField.REFERENCE: "reference",
}

_RAW_SYNONYMS: dict[LogicalField, tuple[str, ...]] = {
    LogicalField.TXN_ID: ("txn id", "transaction id", "id", "entry id", "unique id", "txnid"),
    LogicalField.OCCURRED_AT: (
        "date",
        "txn date",
        "transaction date",
        "posted on",
        "posted at",
        "value date",
        "timestamp",
        "date time",
        "datetime",
    ),
    LogicalField.AMOUNT: (
        "amount",
        "amt",
        "value",
        "debit amount",
        "amount minor",
        "amount paise",
        "amount inr",
    ),
    LogicalField.DIRECTION: ("direction", "dr cr", "cr dr", "debit credit", "in out", "flow"),
    LogicalField.ACCOUNT: ("account", "account name", "bank", "bank account", "source account"),
    LogicalField.INSTRUMENT: (
        "instrument",
        "payment method",
        "payment mode",
        "method",
        "mode",
        "paid via",
        "channel",
    ),
    LogicalField.COUNTERPARTY: (
        "counterparty",
        "merchant",
        "payee",
        "description",
        "particulars",
        "narration",
        "vendor",
        "paid to",
        "details",
    ),
    LogicalField.CATEGORY: ("category", "cat", "bucket", "head", "expense category"),
    LogicalField.TAGS: ("tags", "tag", "labels", "label"),
    LogicalField.NOTE: ("note", "notes", "remark", "remarks", "comment", "comments", "memo"),
    LogicalField.SPLIT_GROUP: ("split group", "split", "split id"),
    LogicalField.SINKING_FUND: ("sinking fund", "fund", "fund id"),
    LogicalField.AMORTIZED: ("amortized", "amortised", "is amortized", "amortize"),
    LogicalField.SOURCE: ("source", "source channel", "captured from", "origin"),
    LogicalField.STATUS: ("status", "state", "confirmation"),
    LogicalField.REFERENCE: (
        "reference",
        "ref",
        "ref no",
        "reference no",
        "reference number",
        "utr",
        "rrn",
    ),
}


def normalize_header(header: str) -> str:
    """casefold, drop punctuation, collapse whitespace."""
    if not isinstance(header, str):
        return ""
    cleaned = "".join(ch if ch.isalnum() else " " for ch in header.casefold())
    return " ".join(cleaned.split())


def _build_synonym_index() -> dict[str, LogicalField]:
    index: dict[str, LogicalField] = {}
    for logical, synonyms in _RAW_SYNONYMS.items():
        candidates = {
            normalize_header(logical.value),
            normalize_header(CANONICAL_HEADERS[logical]),
            *(normalize_header(synonym) for synonym in synonyms),
        }
        for candidate in candidates:
            if not candidate:
                continue
            owner = index.get(candidate)
            if owner is not None and owner is not logical:
                raise SchemaError(
                    f"synonym {candidate!r} claimed by both {owner.value} and {logical.value}"
                )
            index[candidate] = logical
    return index


SYNONYM_INDEX: dict[str, LogicalField] = _build_synonym_index()


def column_letter(index: int) -> str:
    """0-based column index to an A1 column label (0 -> ``A``)."""
    if index < 0:
        raise ValueError("column index must be >= 0")
    letters = ""
    index += 1
    while index:
        index, remainder = divmod(index - 1, 26)
        letters = chr(ord("A") + remainder) + letters
    return letters


@dataclass(frozen=True, slots=True)
class ColumnMapping:
    """Which spreadsheet column holds which logical field."""

    headers: tuple[str, ...]
    columns: dict[LogicalField, int] = field(default_factory=dict)
    created: frozenset[LogicalField] = frozenset()

    def __post_init__(self) -> None:
        seen: dict[int, LogicalField] = {}
        for logical, index in self.columns.items():
            if index < 0 or index >= len(self.headers):
                raise SchemaError(f"column index {index} for {logical.value} is outside the header")
            if index in seen:
                raise SchemaError(
                    f"column {column_letter(index)} claimed by "
                    f"{seen[index].value} and {logical.value}"
                )
            seen[index] = logical

    @property
    def width(self) -> int:
        return len(self.headers)

    @property
    def mapped_fields(self) -> tuple[LogicalField, ...]:
        return tuple(f for f in FIELD_ORDER if f in self.columns)

    @property
    def missing_fields(self) -> tuple[LogicalField, ...]:
        return tuple(f for f in FIELD_ORDER if f not in self.columns)

    @property
    def missing_required(self) -> tuple[LogicalField, ...]:
        return tuple(f for f in self.missing_fields if f in REQUIRED_FIELDS)

    @property
    def user_columns(self) -> tuple[int, ...]:
        owned = set(self.columns.values())
        return tuple(i for i in range(self.width) if i not in owned)

    def is_mapped(self, logical: LogicalField) -> bool:
        return logical in self.columns

    def index_of(self, logical: LogicalField) -> int:
        """Read index for ``logical``; raises when the field has no column."""
        try:
            return self.columns[logical]
        except KeyError:
            raise UnmappedFieldError(
                f"{logical.value} has no column in this spreadsheet"
            ) from None

    def write_index(self, logical: LogicalField) -> int:
        """Write target for ``logical``.

        Refuses any field that was neither detected nor created by the agent:
        writing into an unknown column is the ledger-corruption scenario.
        """
        if logical not in self.columns:
            raise UnmappedFieldError(
                f"refusing to write {logical.value}: no column was mapped or created for it"
            )
        return self.columns[logical]

    def owns_column(self, index: int) -> bool:
        return index in set(self.columns.values())

    def with_created_columns(self, fields: tuple[LogicalField, ...]) -> ColumnMapping:
        """Append ``fields`` as new columns to the right of everything existing."""
        headers = list(self.headers)
        columns = dict(self.columns)
        created = set(self.created)
        for logical in fields:
            if logical in columns:
                raise SchemaError(f"{logical.value} is already mapped; refusing to duplicate it")
            columns[logical] = len(headers)
            headers.append(CANONICAL_HEADERS[logical])
            created.add(logical)
        return ColumnMapping(tuple(headers), columns, frozenset(created))

    def require_complete(self) -> None:
        if self.missing_required:
            names = ", ".join(f.value for f in self.missing_required)
            raise UnmappedFieldError(f"required fields have no column: {names}")


def detect_mapping(header_row: list[str] | tuple[str, ...]) -> ColumnMapping:
    """Map an existing header row onto the agent's logical fields.

    Raises ``AmbiguousColumnError`` when a logical field has more than one
    candidate header, or when one header matches more than one field.
    """
    headers = tuple(str(h) for h in header_row)
    candidates: dict[LogicalField, list[int]] = {}
    for index, header in enumerate(headers):
        normalized = normalize_header(header)
        if not normalized:
            continue
        logical = SYNONYM_INDEX.get(normalized)
        if logical is None:
            continue
        candidates.setdefault(logical, []).append(index)

    ambiguous = {
        logical: indexes for logical, indexes in candidates.items() if len(indexes) > 1
    }
    if ambiguous:
        detail = "; ".join(
            f"{logical.value} <- "
            + ", ".join(f"{column_letter(i)}:{headers[i]!r}" for i in indexes)
            for logical, indexes in sorted(ambiguous.items())
        )
        raise AmbiguousColumnError(f"multiple columns match the same field: {detail}")

    columns = {logical: indexes[0] for logical, indexes in candidates.items()}
    return ColumnMapping(headers, columns)


def plan_missing_columns(mapping: ColumnMapping) -> tuple[LogicalField, ...]:
    """Agent-owned fields that must be appended, in canonical order."""
    return mapping.missing_fields


def dry_run_report(mapping: ColumnMapping) -> str:
    """Human-readable mapping report; the user reviews this before any write."""
    lines = ["Column mapping (dry run)", "=" * 24, ""]
    lines.append("Detected:")
    detected = [f for f in mapping.mapped_fields if f not in mapping.created]
    if detected:
        for logical in detected:
            index = mapping.columns[logical]
            lines.append(
                f"  {logical.value:<14} -> {column_letter(index)}  {mapping.headers[index]!r}"
            )
    else:
        lines.append("  (none)")

    lines.append("")
    lines.append("To be created (appended to the right):")
    planned = plan_missing_columns(mapping)
    created = tuple(f for f in mapping.mapped_fields if f in mapping.created)
    if planned or created:
        for logical in created:
            index = mapping.columns[logical]
            lines.append(f"  {logical.value:<14} -> {column_letter(index)}  (new)")
        next_index = mapping.width
        for logical in planned:
            lines.append(
                f"  {logical.value:<14} -> {column_letter(next_index)}  (planned)"
            )
            next_index += 1
    else:
        lines.append("  (none)")

    lines.append("")
    untouched = mapping.user_columns
    lines.append("Left untouched (user columns):")
    if untouched:
        for index in untouched:
            lines.append(f"  {column_letter(index)}  {mapping.headers[index]!r}")
    else:
        lines.append("  (none)")

    missing_required = mapping.missing_required
    lines.append("")
    if missing_required:
        names = ", ".join(f.value for f in missing_required)
        lines.append(f"REQUIRED FIELDS STILL UNMAPPED: {names}")
    else:
        lines.append("All required fields are mapped.")
    return "\n".join(lines)


_TRUE_VALUES = frozenset({"true", "yes", "y", "1", "t"})
_FALSE_VALUES = frozenset({"false", "no", "n", "0", "f", ""})


def _encode(logical: LogicalField, txn: Transaction) -> str:
    match logical:
        case LogicalField.TXN_ID:
            return txn.txn_id
        case LogicalField.OCCURRED_AT:
            return txn.occurred_at.isoformat()
        case LogicalField.AMOUNT:
            return str(require_minor(txn.amount_minor))
        case LogicalField.DIRECTION:
            return txn.direction.value
        case LogicalField.ACCOUNT:
            return txn.account.value
        case LogicalField.INSTRUMENT:
            return txn.instrument.value
        case LogicalField.COUNTERPARTY:
            return txn.counterparty
        case LogicalField.CATEGORY:
            return txn.category
        case LogicalField.TAGS:
            return ",".join(txn.tags)
        case LogicalField.NOTE:
            return txn.note
        case LogicalField.SPLIT_GROUP:
            return txn.split_group
        case LogicalField.SINKING_FUND:
            return txn.sinking_fund
        case LogicalField.AMORTIZED:
            return "TRUE" if txn.amortized else "FALSE"
        case LogicalField.SOURCE:
            return txn.source.value
        case LogicalField.STATUS:
            return txn.status.value
        case LogicalField.REFERENCE:
            return txn.reference
    raise SchemaError(f"no encoder for {logical}")  # pragma: no cover - exhaustive match


def to_row(txn: Transaction, mapping: ColumnMapping) -> list[str]:
    """Render ``txn`` into a full-width row, leaving user columns blank."""
    mapping.require_complete()
    row = [""] * mapping.width
    for logical in mapping.mapped_fields:
        row[mapping.write_index(logical)] = _encode(logical, txn)
    return row


def _cell(row: list[str] | tuple[str, ...], index: int) -> str:
    return str(row[index]).strip() if index < len(row) else ""


def _parse_enum(enum_cls: type[StrEnum], value: str, fallback: StrEnum | None) -> StrEnum:
    if not value:
        if fallback is None:
            raise SchemaError(f"missing {enum_cls.__name__} value")
        return fallback
    try:
        return enum_cls(value.strip().lower() if enum_cls is not Account else value.strip().upper())
    except ValueError as exc:
        raise SchemaError(f"unknown {enum_cls.__name__} value: {value!r}") from exc


def _parse_bool(value: str) -> bool:
    lowered = value.strip().casefold()
    if lowered in _TRUE_VALUES:
        return True
    if lowered in _FALSE_VALUES:
        return False
    raise SchemaError(f"not a boolean: {value!r}")


def is_blank_row(row: list[str] | tuple[str, ...]) -> bool:
    return all(not str(cell).strip() for cell in row)


def from_row(row: list[str] | tuple[str, ...], mapping: ColumnMapping) -> Transaction:
    """Rebuild a ``Transaction`` from a spreadsheet row."""
    mapping.require_complete()

    raw_amount = _cell(row, mapping.index_of(LogicalField.AMOUNT))
    try:
        amount_minor = int(raw_amount)
    except ValueError as exc:
        raise SchemaError(f"malformed amount: {raw_amount!r}") from exc

    raw_when = _cell(row, mapping.index_of(LogicalField.OCCURRED_AT))
    try:
        occurred_at = datetime.fromisoformat(raw_when)
    except ValueError as exc:
        raise SchemaError(f"malformed timestamp: {raw_when!r}") from exc
    if occurred_at.tzinfo is None:
        raise SchemaError(f"timestamp has no UTC offset: {raw_when!r}")

    txn_id = _cell(row, mapping.index_of(LogicalField.TXN_ID))
    if not txn_id:
        raise SchemaError("row has no txn_id")

    def optional(logical: LogicalField) -> str:
        if not mapping.is_mapped(logical):
            return ""
        return _cell(row, mapping.index_of(logical))

    tags = tuple(tag.strip() for tag in optional(LogicalField.TAGS).split(",") if tag.strip())
    amortized_cell = optional(LogicalField.AMORTIZED)

    try:
        return Transaction(
            txn_id=txn_id,
            occurred_at=occurred_at,
            amount_minor=amount_minor,
            direction=_parse_enum(Direction, _cell(row, mapping.index_of(LogicalField.DIRECTION)), None),  # type: ignore[arg-type]
            account=_parse_enum(Account, _cell(row, mapping.index_of(LogicalField.ACCOUNT)), None),  # type: ignore[arg-type]
            instrument=_parse_enum(Instrument, optional(LogicalField.INSTRUMENT), Instrument.UNKNOWN),  # type: ignore[arg-type]
            counterparty=optional(LogicalField.COUNTERPARTY),
            currency=DEFAULT_CURRENCY,
            category=optional(LogicalField.CATEGORY),
            tags=tags,
            note=optional(LogicalField.NOTE),
            split_group=optional(LogicalField.SPLIT_GROUP),
            sinking_fund=optional(LogicalField.SINKING_FUND),
            amortized=_parse_bool(amortized_cell),
            source=_parse_enum(SourceChannel, optional(LogicalField.SOURCE), SourceChannel.MANUAL),  # type: ignore[arg-type]
            status=_parse_enum(TxnStatus, optional(LogicalField.STATUS), TxnStatus.NEEDS_REVIEW),  # type: ignore[arg-type]
            reference=optional(LogicalField.REFERENCE),
        )
    except (ValueError, TypeError) as exc:
        raise SchemaError(f"row {txn_id!r} is not a valid transaction: {exc}") from exc
