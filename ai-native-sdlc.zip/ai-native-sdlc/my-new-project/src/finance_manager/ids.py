"""Deterministic transaction identifiers.

``txn_id`` is the idempotency key for the whole system: the Sheets API has no
native upsert, so duplicate suppression is client-side and depends on the same
real payment always producing the same id — including when it is captured twice
on two different devices (spec FR-S2, §3).

The id is therefore **derived**, not random: a 26-char Crockford-base32 string
whose first 10 chars encode a coarse time bucket (so ids sort roughly by time)
and whose remaining 16 chars are a BLAKE2b digest of the identifying fields.
"""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime

from .money import require_minor

_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"  # Crockford base32, no I/L/O/U
TIME_BUCKET_SECONDS = 180
"""Captures of one payment can disagree on timestamp; bucket before hashing.

Must match the dedup window in ``capture.dedup`` so that two captures that
dedup together also hash together.
"""


def _b32(value: int, length: int) -> str:
    chars = []
    for _ in range(length):
        value, rem = divmod(value, 32)
        chars.append(_ALPHABET[rem])
    return "".join(reversed(chars))


def normalize_counterparty(name: str | None) -> str:
    """Lowercase, strip punctuation and common noise from a merchant string.

    Used both for id derivation and for dedup matching, so the two never drift.
    """
    if not name:
        return ""
    cleaned = "".join(ch.lower() if ch.isalnum() else " " for ch in name)
    noise = {"pvt", "ltd", "limited", "india", "the", "upi", "pay", "payment"}
    tokens = [tok for tok in cleaned.split() if tok and tok not in noise]
    return " ".join(tokens)


def time_bucket(moment: datetime, *, seconds: int = TIME_BUCKET_SECONDS) -> int:
    """Floor a timestamp to a bucket, in UTC epoch seconds."""
    if moment.tzinfo is None:
        raise ValueError("timestamp must be timezone-aware")
    epoch = int(moment.astimezone(UTC).timestamp())
    return epoch - (epoch % seconds)


def derive_txn_id(
    *,
    amount_minor: int,
    occurred_at: datetime,
    account: str,
    reference: str | None = None,
    counterparty: str | None = None,
) -> str:
    """Derive the canonical ``txn_id`` for a payment.

    When the issuer supplies a reference number it dominates: it is globally
    unique per payment, so the id ignores the time bucket's edge effects by
    folding the reference in directly.
    """
    require_minor(amount_minor)
    bucket = time_bucket(occurred_at)
    ref = (reference or "").strip().upper()
    key = "|".join(
        [
            str(amount_minor),
            str(bucket),
            account.strip().upper(),
            ref,
            "" if ref else normalize_counterparty(counterparty),
        ]
    )
    digest = hashlib.blake2b(key.encode("utf-8"), digest_size=10).digest()
    return _b32(bucket, 10) + _b32(int.from_bytes(digest, "big"), 16)


def is_txn_id(value: str) -> bool:
    """True when ``value`` has the shape of a derived transaction id."""
    return isinstance(value, str) and len(value) == 26 and all(ch in _ALPHABET for ch in value)
