"""Error hierarchy for the Finance Manager core."""

from __future__ import annotations


class FinanceManagerError(Exception):
    """Base class for every error raised by this package."""


class MoneyError(FinanceManagerError):
    """Invalid monetary value or unsafe monetary operation."""


class FloatMoneyError(MoneyError):
    """A float reached the money layer.

    Money is exact integer minor units end to end (spec NFR-3). Floats are
    rejected loudly rather than silently rounded.
    """


class ParseError(FinanceManagerError):
    """A raw capture could not be parsed into a transaction."""


class RedactedInputError(ParseError):
    """Input was dropped because it carries a secret (OTP/PIN/PAN).

    Spec NFR-5: such text must never reach the parser or the ledger.
    """


class SchemaError(FinanceManagerError):
    """The spreadsheet schema could not be mapped safely."""


class AmbiguousColumnError(SchemaError):
    """Two or more existing columns matched one logical field.

    The agent raises instead of guessing: a wrong mapping would corrupt a real
    ledger (plan risk #1).
    """


class UnmappedFieldError(SchemaError):
    """A required logical field has no column and could not be created."""


class SheetsError(FinanceManagerError):
    """A Google Sheets operation failed."""


class QuotaError(SheetsError):
    """The Sheets API rate limit was hit and retries were exhausted."""


class ConflictError(SheetsError):
    """The spreadsheet changed underneath an in-flight write."""


class BudgetError(FinanceManagerError):
    """Invalid budget, sinking fund, or amortization operation."""


class FundOverdrawError(BudgetError):
    """A sinking fund drawdown exceeded its available balance."""


class EnrichmentError(FinanceManagerError):
    """Invalid enrichment prompt transition or payload."""


class ConfigError(FinanceManagerError):
    """Configuration is missing or invalid."""


class QueueError(FinanceManagerError):
    """The durable capture queue could not complete an operation."""


class PayloadError(QueueError):
    """A queued payload could not be serialized or decoded.

    Raised (or recorded against the item) instead of dropping work: a corrupt
    row becomes a visible ``failed`` item, never a silent loss (spec NFR-9).
    """
