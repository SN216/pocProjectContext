"""Configuration loading.

Configuration is plain JSON plus environment variables. **No secret ever lives
in this file or in the repository** (spec NFR-4): OAuth refresh tokens and SMTP
passwords are read from the OS secret store or the environment at run time, and
`scan_secrets.py` runs before every commit.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from .errors import ConfigError
from .money import require_minor, to_minor

ENV_PREFIX = "FM_"
DEFAULT_CONFIG_NAME = "finance_manager.config.json"


@dataclass(frozen=True, slots=True)
class SheetsConfig:
    spreadsheet_id: str = ""
    transactions_tab: str = "Transactions"
    budgets_tab: str = "Budgets"
    funds_tab: str = "SinkingFunds"
    sips_tab: str = "SIPs"
    reports_tab: str = "Reports"
    state_tab: str = "_AgentState"
    batch_size: int = 100

    def __post_init__(self) -> None:
        if self.batch_size < 1 or self.batch_size > 500:
            raise ConfigError("batch_size must be between 1 and 500")


@dataclass(frozen=True, slots=True)
class AlertConfig:
    caution_thresholds: tuple[int, ...] = (80, 90)
    hard_threshold: int = 100
    routing: dict[str, tuple[str, ...]] = field(
        default_factory=lambda: {
            "80": ("push",),
            "90": ("push",),
            "100": ("push", "email"),
            "fund_overdraw": ("email",),
            "large_expense": ("email",),
            "sip_mismatch": ("push", "email"),
            "monthly_report": ("email",),
        }
    )
    max_alerts_per_month: int = 20

    def __post_init__(self) -> None:
        for threshold in (*self.caution_thresholds, self.hard_threshold):
            if not 1 <= threshold <= 100:
                raise ConfigError(f"threshold out of range: {threshold}")


@dataclass(frozen=True, slots=True)
class AmortizationConfig:
    """Knobs for the 1/5th income rule (spec §4)."""

    income_divisor: int = 5
    income_window_months: int = 3
    fallback_monthly_income_minor: int = 0
    deviation_tolerance_pct: int = 50

    def __post_init__(self) -> None:
        if self.income_divisor < 1:
            raise ConfigError("income_divisor must be >= 1")
        if self.income_window_months < 1:
            raise ConfigError("income_window_months must be >= 1")
        require_minor(self.fallback_monthly_income_minor)


@dataclass(frozen=True, slots=True)
class CaptureConfig:
    dedup_window_seconds: int = 180
    prompt_timeout_seconds: int = 1800
    raw_retention_days: int = 30
    allowed_packages: tuple[str, ...] = (
        "com.google.android.apps.nbu.paisa.user",
        "com.snapwork.hdfc",
        "com.sbi.lotusintouch",
        "com.sbi.SBIFreedomPlus",
    )
    allowed_sms_senders: tuple[str, ...] = (
        "HDFCBK",
        "SBIBNK",
        "SBIUPI",
        "SBICRD",
        "HDFCBN",
    )
    allowed_email_senders: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.dedup_window_seconds < 1:
            raise ConfigError("dedup_window_seconds must be >= 1")
        if self.raw_retention_days < 1:
            raise ConfigError("raw_retention_days must be >= 1")


@dataclass(frozen=True, slots=True)
class Config:
    sheets: SheetsConfig = field(default_factory=SheetsConfig)
    alerts: AlertConfig = field(default_factory=AlertConfig)
    amortization: AmortizationConfig = field(default_factory=AmortizationConfig)
    capture: CaptureConfig = field(default_factory=CaptureConfig)
    queue_path: str = "finance_manager_queue.sqlite3"

    @classmethod
    def load(cls, path: str | Path | None = None, env: dict[str, str] | None = None) -> Config:
        """Load config from JSON, then overlay ``FM_``-prefixed env vars."""
        env = dict(os.environ if env is None else env)
        data: dict[str, object] = {}
        candidate = Path(path) if path else Path(DEFAULT_CONFIG_NAME)
        if candidate.exists():
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                raise ConfigError(f"invalid config JSON in {candidate}: {exc}") from exc
            if not isinstance(data, dict):
                raise ConfigError(f"config root must be an object: {candidate}")

        sheets_data = dict(data.get("sheets", {}) or {})  # type: ignore[arg-type]
        amort_data = dict(data.get("amortization", {}) or {})  # type: ignore[arg-type]
        capture_data = dict(data.get("capture", {}) or {})  # type: ignore[arg-type]
        alerts_data = dict(data.get("alerts", {}) or {})  # type: ignore[arg-type]

        if spreadsheet_id := env.get(f"{ENV_PREFIX}SPREADSHEET_ID"):
            sheets_data["spreadsheet_id"] = spreadsheet_id
        if fallback := env.get(f"{ENV_PREFIX}FALLBACK_MONTHLY_INCOME"):
            amort_data["fallback_monthly_income_minor"] = to_minor(fallback)

        for key in ("allowed_packages", "allowed_sms_senders", "allowed_email_senders"):
            if key in capture_data:
                capture_data[key] = tuple(capture_data[key])  # type: ignore[index]
        if "caution_thresholds" in alerts_data:
            alerts_data["caution_thresholds"] = tuple(alerts_data["caution_thresholds"])  # type: ignore[index]
        if "routing" in alerts_data:
            alerts_data["routing"] = {
                key: tuple(value)
                for key, value in alerts_data["routing"].items()  # type: ignore[union-attr]
            }

        return cls(
            sheets=SheetsConfig(**sheets_data),  # type: ignore[arg-type]
            alerts=AlertConfig(**alerts_data),  # type: ignore[arg-type]
            amortization=AmortizationConfig(**amort_data),  # type: ignore[arg-type]
            capture=CaptureConfig(**capture_data),  # type: ignore[arg-type]
            queue_path=str(data.get("queue_path", "finance_manager_queue.sqlite3")),
        )


def secret_from_env(name: str, *, required: bool = True) -> str:
    """Read a secret from the environment.

    Secrets are never read from the config file or the repository; this is the
    single approved entry point so the rule is greppable.
    """
    value = os.environ.get(f"{ENV_PREFIX}{name}", "")
    if required and not value:
        raise ConfigError(
            f"missing secret {ENV_PREFIX}{name}; set it in the environment or OS keyring"
        )
    return value
