"""Finance Manager core package.

The Google Sheet "Financial Budget Planner" is the system of record; everything
in this package is a rebuildable projection of it.
"""

__version__ = "0.1.0"
