"""Core domain model.

These types are the contract between every module: capture produces
``RawCapture``, the parser turns it into ``Transaction``, enrichment fills the
user-supplied fields, and the Sheets repository persists it. Amounts are always
integer minor units (see :mod:`finance_manager.money`).
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date, datetime
from enum import StrEnum

from .errors import BudgetError, EnrichmentError
from .ids import derive_txn_id
from .money import require_minor, split_evenly


class Direction(StrEnum):
    DEBIT = "debit"
    CREDIT = "credit"


class Account(StrEnum):
    """Accounts and cards from intent §2."""

    HDFC_SALARY = "HDFC_SALARY"
    SBI_SAVINGS = "SBI_SAVINGS"
    SBI_ELITE_CC = "SBI_ELITE_CC"
    HDFC_GOLD_CC = "HDFC_GOLD_CC"  # applied, not yet issued (spec G9)
    PIXEL_RUPAY = "PIXEL_RUPAY"
    CASH = "CASH"
    UNKNOWN = "UNKNOWN"


class Instrument(StrEnum):
    UPI_GPAY = "UPI_GPAY"
    CARD = "CARD"
    NETBANKING = "NETBANKING"
    AUTO_DEBIT = "AUTO_DEBIT"
    CASH = "CASH"
    UNKNOWN = "UNKNOWN"


class SourceChannel(StrEnum):
    """Where a capture came from (spec §3). Drives the per-platform tiers."""

    ANDROID_NOTIF = "android_notif"
    ANDROID_SMS = "android_sms"
    IOS_SHORTCUT = "ios_shortcut"
    IOS_SHARE = "ios_share"
    IOS_EMAIL = "ios_email"
    MANUAL = "manual"


class TxnStatus(StrEnum):
    CONFIRMED = "confirmed"
    NEEDS_REVIEW = "needs_review"
    VOID = "void"


class AlertKind(StrEnum):
    BUDGET_CAUTION = "budget_caution"
    BUDGET_LIMIT = "budget_limit"
    FUND_OVERDRAW = "fund_overdraw"
    LARGE_EXPENSE = "large_expense"
    SIP_MISMATCH = "sip_mismatch"
    NEEDS_REVIEW_DIGEST = "needs_review_digest"
    MONTHLY_REPORT = "monthly_report"


@dataclass(frozen=True, slots=True)
class RawCapture:
    """An unparsed payment signal, exactly as the platform delivered it."""

    source: SourceChannel
    received_at: datetime
    text: str
    package: str | None = None
    sender: str | None = None
    hints: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.received_at.tzinfo is None:
            raise ValueError("received_at must be timezone-aware")


@dataclass(frozen=True, slots=True)
class Transaction:
    """A normalized ledger row. Mirrors the Sheet's logical fields."""

    txn_id: str
    occurred_at: datetime
    amount_minor: int
    direction: Direction
    account: Account
    instrument: Instrument = Instrument.UNKNOWN
    counterparty: str = ""
    currency: str = "INR"
    category: str = ""
    tags: tuple[str, ...] = ()
    note: str = ""
    split_group: str = ""
    sinking_fund: str = ""
    amortized: bool = False
    source: SourceChannel = SourceChannel.MANUAL
    status: TxnStatus = TxnStatus.NEEDS_REVIEW
    reference: str = ""
    sources: tuple[SourceChannel, ...] = ()
    raw_refs: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        require_minor(self.amount_minor)
        if self.amount_minor <= 0:
            raise ValueError("amount_minor must be positive; use direction for sign")
        if self.occurred_at.tzinfo is None:
            raise ValueError("occurred_at must be timezone-aware")

    @property
    def signed_minor(self) -> int:
        """Negative for debits, positive for credits."""
        return -self.amount_minor if self.direction is Direction.DEBIT else self.amount_minor

    @property
    def month(self) -> str:
        """``YYYY-MM`` bucket used by budgets and reports."""
        return self.occurred_at.strftime("%Y-%m")

    @property
    def is_enriched(self) -> bool:
        return bool(self.category) and self.status is TxnStatus.CONFIRMED

    def with_enrichment(
        self,
        *,
        category: str,
        tags: tuple[str, ...] = (),
        note: str = "",
        sinking_fund: str = "",
        amortized: bool = False,
    ) -> Transaction:
        """Return a confirmed copy carrying the user's metadata (spec FR-E4)."""
        if not category:
            raise EnrichmentError("category is required to confirm a transaction")
        if amortized and not sinking_fund:
            raise EnrichmentError("amortized transactions must name a sinking fund")
        return replace(
            self,
            category=category,
            tags=tags,
            note=note,
            sinking_fund=sinking_fund,
            amortized=amortized,
            status=TxnStatus.CONFIRMED,
        )

    def split(self, allocations: list[tuple[str, int]]) -> list[Transaction]:
        """Divide into category lines whose amounts sum **exactly** to this one.

        Spec FR-E5. Raises when the allocation does not reconcile, so a split can
        never silently create or destroy money.
        """
        if len(allocations) < 2:
            raise EnrichmentError("a split needs at least two lines")
        total = 0
        for _, amount in allocations:
            require_minor(amount)
            if amount <= 0:
                raise EnrichmentError("split amounts must be positive")
            total += amount
        if total != self.amount_minor:
            raise EnrichmentError(f"split lines sum to {total}, expected {self.amount_minor}")
        group = self.txn_id
        lines = []
        for index, (category, amount) in enumerate(allocations):
            lines.append(
                replace(
                    self,
                    txn_id=f"{group}-{index + 1}",
                    amount_minor=amount,
                    category=category,
                    split_group=group,
                    status=TxnStatus.CONFIRMED,
                )
            )
        return lines

    @classmethod
    def from_capture(
        cls,
        *,
        amount_minor: int,
        occurred_at: datetime,
        direction: Direction,
        account: Account,
        source: SourceChannel,
        instrument: Instrument = Instrument.UNKNOWN,
        counterparty: str = "",
        reference: str = "",
        **kwargs: object,
    ) -> Transaction:
        """Build a transaction with a derived, reproducible ``txn_id``."""
        txn_id = derive_txn_id(
            amount_minor=amount_minor,
            occurred_at=occurred_at,
            account=account.value,
            reference=reference or None,
            counterparty=counterparty or None,
        )
        return cls(
            txn_id=txn_id,
            occurred_at=occurred_at,
            amount_minor=amount_minor,
            direction=direction,
            account=account,
            instrument=instrument,
            counterparty=counterparty,
            reference=reference,
            source=source,
            sources=(source,),
            **kwargs,  # type: ignore[arg-type]
        )


@dataclass(frozen=True, slots=True)
class Budget:
    """A monthly category budget, read from the Sheet's ``Budgets`` tab."""

    category: str
    monthly_limit_minor: int

    def __post_init__(self) -> None:
        require_minor(self.monthly_limit_minor)
        if self.monthly_limit_minor <= 0:
            raise BudgetError("monthly_limit_minor must be positive")


@dataclass(frozen=True, slots=True)
class SinkingFund:
    """An annual sinking fund, e.g. Travel = ₹1.2L/yr at ₹10k/month."""

    fund_id: str
    name: str
    annual_target_minor: int
    monthly_allocation_minor: int
    period_start: date
    categories: tuple[str, ...] = ()
    drawn_minor: int = 0

    def __post_init__(self) -> None:
        require_minor(self.annual_target_minor)
        require_minor(self.monthly_allocation_minor)
        require_minor(self.drawn_minor)
        if self.annual_target_minor <= 0:
            raise BudgetError("annual_target_minor must be positive")
        if self.drawn_minor < 0:
            raise BudgetError("drawn_minor cannot be negative")

    @property
    def balance_minor(self) -> int:
        """Remaining headroom against the annual target (spec FR-A4)."""
        return self.annual_target_minor - self.drawn_minor

    def accrued_minor(self, months_elapsed: int) -> int:
        """Allocation accrued so far, capped at the annual target."""
        if months_elapsed < 0:
            raise BudgetError("months_elapsed cannot be negative")
        return min(self.monthly_allocation_minor * months_elapsed, self.annual_target_minor)

    def monthly_schedule(self, months: int = 12) -> list[int]:
        """Amortized view: the drawn amount spread across the fund year."""
        return split_evenly(self.drawn_minor, months)


@dataclass(frozen=True, slots=True)
class Sip:
    """A recurring investment (intent §6)."""

    sip_id: str
    name: str
    amount_minor: int
    debit_day: int
    account: Account
    active: bool = True

    def __post_init__(self) -> None:
        require_minor(self.amount_minor)
        if not 1 <= self.debit_day <= 28:
            raise BudgetError("debit_day must be between 1 and 28")


@dataclass(frozen=True, slots=True)
class Alert:
    """An outbound notification (spec §5)."""

    kind: AlertKind
    subject: str
    body: str
    month: str = ""
    category: str = ""
    channels: tuple[str, ...] = ("push",)
