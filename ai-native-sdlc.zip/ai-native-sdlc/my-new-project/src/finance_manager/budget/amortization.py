"""The 1/5th income amortization rule (spec §4, G5).

The rule **proposes**; the user **disposes**. ``evaluate`` can only ever produce a
proposal; the sole path to an amortized transaction is ``apply``, which demands a
``UserConfirmation``. There is no code path that amortizes silently — that is the
structural guard against amortization being used to hide real overspending.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from ..config import AlertConfig, AmortizationConfig
from ..errors import BudgetError
from ..models import Alert, AlertKind, SinkingFund, Transaction, TxnStatus
from ..money import format_inr, require_minor, split_evenly
from .sinking_funds import DrawdownResult, FundRegistry, drawdown, overdraw_alert


class ProposedAction(StrEnum):
    """The four-way outcome of spec §4's decision flow."""

    CHARGE_TO_MONTH = "charge_to_month"
    PROPOSE_AMORTIZATION = "propose_amortization"
    PROPOSE_CREATE_FUND = "propose_create_fund"


def amortization_threshold(monthly_income_minor: int, config: AmortizationConfig | None = None) -> int:
    """``M / divisor`` as an exact integer threshold.

    Rounded **up** so that ``amount >= threshold`` is exactly equivalent to the
    spec's ``E * divisor >= M`` — no float, no rounding drift.
    """
    config = config or AmortizationConfig()
    require_minor(monthly_income_minor)
    if monthly_income_minor <= 0:
        raise BudgetError("monthly income must be positive to derive an amortization threshold")
    return -(-monthly_income_minor // config.income_divisor)


def is_candidate(
    amount_minor: int, monthly_income_minor: int, config: AmortizationConfig | None = None
) -> bool:
    """``E >= M/5``. The boundary is inclusive."""
    config = config or AmortizationConfig()
    require_minor(amount_minor)
    return amount_minor * config.income_divisor >= monthly_income_minor


@dataclass(frozen=True, slots=True)
class AmortizationDecision:
    """A proposal the enrichment prompt can render verbatim."""

    amount_minor: int
    category: str
    month: str
    candidate: bool
    action: ProposedAction
    threshold_minor: int
    monthly_income_minor: int
    reason: str
    default_on: bool = False
    fund_id: str = ""
    fund_name: str = ""
    fund_balance_minor: int = 0
    resulting_balance_minor: int = 0
    overdraw_minor: int = 0

    @property
    def proposes_amortization(self) -> bool:
        return self.action is ProposedAction.PROPOSE_AMORTIZATION

    @property
    def requires_confirmation(self) -> bool:
        return self.action is not ProposedAction.CHARGE_TO_MONTH


@dataclass(frozen=True, slots=True)
class UserConfirmation:
    """An explicit human answer to a proposal (FR-E1, G5)."""

    confirmed: bool
    decided_at: datetime
    actor: str = "user"
    note: str = ""

    def __post_init__(self) -> None:
        if self.decided_at.tzinfo is None:
            raise ValueError("decided_at must be timezone-aware")


@dataclass(frozen=True, slots=True)
class AmortizationOutcome:
    """What actually happened once the user answered."""

    transaction: Transaction
    decision: AmortizationDecision
    amortized: bool
    fund: SinkingFund | None = None
    registry: FundRegistry | None = None
    drawdown: DrawdownResult | None = None
    alerts: tuple[Alert, ...] = ()

    @property
    def charged_to_month(self) -> bool:
        return not self.amortized


def evaluate(
    txn: Transaction,
    *,
    monthly_income_minor: int,
    registry: FundRegistry | None = None,
    config: AmortizationConfig | None = None,
) -> AmortizationDecision:
    """Run spec §4's decision flow for one expense. Never mutates anything."""
    config = config or AmortizationConfig()
    registry = registry or FundRegistry()
    threshold = amortization_threshold(monthly_income_minor, config)
    amount = txn.amount_minor
    candidate = is_candidate(amount, monthly_income_minor, config)

    if not candidate:
        return AmortizationDecision(
            amount_minor=amount,
            category=txn.category,
            month=txn.month,
            candidate=False,
            action=ProposedAction.CHARGE_TO_MONTH,
            threshold_minor=threshold,
            monthly_income_minor=monthly_income_minor,
            reason=(
                f"{format_inr(amount)} is below the {format_inr(threshold)} amortization "
                f"threshold; charged to {txn.category or 'its category'} for {txn.month}"
            ),
        )

    fund = registry.for_transaction(txn)
    if fund is None:
        return AmortizationDecision(
            amount_minor=amount,
            category=txn.category,
            month=txn.month,
            candidate=True,
            action=ProposedAction.PROPOSE_CREATE_FUND,
            threshold_minor=threshold,
            monthly_income_minor=monthly_income_minor,
            reason=(
                f"{format_inr(amount)} is at or above the {format_inr(threshold)} threshold but "
                f"no sinking fund covers {txn.category or 'this category'}. Create one?"
            ),
        )

    preview = drawdown(fund, amount)
    return AmortizationDecision(
        amount_minor=amount,
        category=txn.category,
        month=txn.month,
        candidate=True,
        action=ProposedAction.PROPOSE_AMORTIZATION,
        threshold_minor=threshold,
        monthly_income_minor=monthly_income_minor,
        default_on=True,
        fund_id=fund.fund_id,
        fund_name=fund.name,
        fund_balance_minor=fund.balance_minor,
        resulting_balance_minor=preview.fund.balance_minor,
        overdraw_minor=preview.overdraw_minor,
        reason=(
            f"{format_inr(amount)} is at or above the {format_inr(threshold)} threshold and maps "
            f"to {fund.name}. Amortize? {format_inr(preview.fund.balance_minor)} would remain"
            + (
                f"; {format_inr(preview.overdraw_minor)} exceeds the fund"
                if preview.is_overdrawn
                else ""
            )
        ),
    )


def large_expense_alert(
    decision: AmortizationDecision, *, alerts: AlertConfig | None = None
) -> Alert:
    """Raised when a candidate is left in-month, so it is never normalized away."""
    alerts = alerts or AlertConfig()
    return Alert(
        kind=AlertKind.LARGE_EXPENSE,
        subject=f"Large expense: {format_inr(decision.amount_minor)} in {decision.category}",
        body=(
            f"{format_inr(decision.amount_minor)} in {decision.category or 'uncategorized'} for "
            f"{decision.month} is at or above the {format_inr(decision.threshold_minor)} "
            "amortization threshold but was charged to the month. It counts fully against the "
            "category budget."
        ),
        month=decision.month,
        category=decision.category,
        channels=alerts.routing.get("large_expense", ("email",)),
    )


def apply(
    txn: Transaction,
    decision: AmortizationDecision,
    confirmation: UserConfirmation,
    *,
    registry: FundRegistry | None = None,
    alerts: AlertConfig | None = None,
) -> AmortizationOutcome:
    """Dispose of a proposal.

    The only way to produce an amortized transaction. A missing or negative
    confirmation always leaves the expense in its month.
    """
    alerts = alerts or AlertConfig()
    if not isinstance(confirmation, UserConfirmation):  # pragma: no cover - defensive
        raise BudgetError("amortization requires an explicit UserConfirmation")

    if not decision.proposes_amortization or not confirmation.confirmed:
        notices: tuple[Alert, ...] = ()
        if decision.candidate:
            notices = (large_expense_alert(decision, alerts=alerts),)
        return AmortizationOutcome(
            transaction=txn,
            decision=decision,
            amortized=False,
            registry=registry,
            alerts=notices,
        )

    if registry is None:
        raise BudgetError("a fund registry is required to amortize")
    fund = registry.get(decision.fund_id)
    result = drawdown(fund, txn.amount_minor)
    amortized_txn = txn.with_enrichment(
        category=txn.category,
        tags=txn.tags,
        note=txn.note,
        sinking_fund=fund.fund_id,
        amortized=True,
    )
    emitted: list[Alert] = []
    if result.is_overdrawn:
        emitted.append(
            overdraw_alert(result, month=txn.month, category=txn.category, alerts=alerts)
        )
    return AmortizationOutcome(
        transaction=amortized_txn,
        decision=decision,
        amortized=True,
        fund=result.fund,
        registry=registry.replace_fund(result.fund),
        drawdown=result,
        alerts=tuple(emitted),
    )


def cash_view(transactions: Iterable[Transaction], *, month: str | None = None) -> dict[str, int]:
    """Actual outflow per month, amortized or not (FR-A5)."""
    totals: dict[str, int] = {}
    for txn in transactions:
        if txn.status is TxnStatus.VOID or txn.signed_minor >= 0:
            continue
        if month is not None and txn.month != month:
            continue
        totals[txn.month] = totals.get(txn.month, 0) + txn.amount_minor
    return totals


def amortized_view(
    fund: SinkingFund, months: Sequence[str], *, transactions: Iterable[Transaction] = ()
) -> dict[str, int]:
    """The fund's drawn total spread evenly across the fund year (FR-A5).

    ``split_evenly`` guarantees the spread sums to exactly the drawn total, so
    the amortized view reconciles with the cash view to the paisa.
    """
    drawn = fund.drawn_minor
    extra = sum(
        txn.amount_minor
        for txn in transactions
        if txn.amortized and txn.sinking_fund == fund.fund_id and txn.status is not TxnStatus.VOID
    )
    total = drawn if not extra else extra
    shares = split_evenly(total, len(months))
    return dict(zip(months, shares, strict=True))
