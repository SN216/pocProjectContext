"""Trailing net monthly income ``M`` — the basis of the 1/5th rule (spec §4, G6).

``M`` sets the amortization threshold, so a wrong ``M`` is a severe failure mode:
an ``M`` of zero would make *every* expense an amortization candidate. This module
therefore never guesses — it either produces an auditable number or raises.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from enum import StrEnum

from ..config import AmortizationConfig
from ..errors import BudgetError
from ..models import Account, Direction, Transaction, TxnStatus

DEFAULT_INCOME_ACCOUNTS: tuple[Account, ...] = (Account.HDFC_SALARY,)
DEFAULT_INCOME_CATEGORIES: tuple[str, ...] = ("Salary", "Income")


class IncomeMethod(StrEnum):
    """How ``M`` was derived — recorded for the `_AgentState` audit trail."""

    MEAN = "mean"
    MEDIAN = "median"
    FALLBACK = "fallback"


@dataclass(frozen=True, slots=True)
class IncomeResult:
    """An auditable computation of ``M``."""

    monthly_income_minor: int
    method: IncomeMethod
    months_used: tuple[str, ...]
    monthly_totals: tuple[tuple[str, int], ...]
    reason: str

    @property
    def used_fallback(self) -> bool:
        return self.method is IncomeMethod.FALLBACK

    @property
    def used_median(self) -> bool:
        return self.method is IncomeMethod.MEDIAN


def is_income(
    txn: Transaction,
    *,
    income_accounts: Sequence[Account] = DEFAULT_INCOME_ACCOUNTS,
    income_categories: Sequence[str] = DEFAULT_INCOME_CATEGORIES,
) -> bool:
    """A credit to a salary account, or to a configured income category."""
    if txn.direction is not Direction.CREDIT or txn.status is TxnStatus.VOID:
        return False
    if txn.account in tuple(income_accounts):
        return True
    return txn.category in tuple(income_categories)


def monthly_net_income(
    transactions: Iterable[Transaction],
    *,
    income_accounts: Sequence[Account] = DEFAULT_INCOME_ACCOUNTS,
    income_categories: Sequence[str] = DEFAULT_INCOME_CATEGORIES,
) -> dict[str, int]:
    """Net income per ``YYYY-MM``.

    Net means credits minus any refund/clawback debit booked against the same
    income account in that month, so a reversed salary credit cannot inflate ``M``.
    """
    accounts = tuple(income_accounts)
    categories = tuple(income_categories)
    totals: dict[str, int] = {}
    for txn in transactions:
        if txn.status is TxnStatus.VOID:
            continue
        credit = is_income(txn, income_accounts=accounts, income_categories=categories)
        clawback = (
            txn.direction is Direction.DEBIT
            and txn.account in accounts
            and txn.category in categories
        )
        if credit or clawback:
            totals[txn.month] = totals.get(txn.month, 0) + txn.signed_minor
    return totals


def _median(values: Sequence[int]) -> int:
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) // 2


def _deviates(value: int, others: Sequence[int], tolerance_pct: int) -> bool:
    """Integer-only check: does ``value`` deviate > tolerance from the mean of ``others``?"""
    if not others:
        return False
    others_sum = sum(others)
    count = len(others)
    # |value - mean(others)| * 100 > mean(others) * tolerance, multiplied through by count.
    return abs(value * count - others_sum) * 100 > others_sum * tolerance_pct


def _fallback(config: AmortizationConfig, reason: str, totals: dict[str, int]) -> IncomeResult:
    fallback = config.fallback_monthly_income_minor
    if fallback <= 0:
        raise BudgetError(
            f"{reason}; no fallback_monthly_income_minor is configured. Refusing to use a zero "
            "income threshold, which would make every expense an amortization candidate "
            "(spec G6). Set FM_FALLBACK_MONTHLY_INCOME or record income history."
        )
    return IncomeResult(
        monthly_income_minor=fallback,
        method=IncomeMethod.FALLBACK,
        months_used=(),
        monthly_totals=tuple(sorted(totals.items())),
        reason=f"{reason}; using configured fallback monthly income",
    )


def compute_monthly_income(
    transactions: Iterable[Transaction],
    config: AmortizationConfig | None = None,
    *,
    as_of_month: str | None = None,
    income_accounts: Sequence[Account] = DEFAULT_INCOME_ACCOUNTS,
    income_categories: Sequence[str] = DEFAULT_INCOME_CATEGORIES,
) -> IncomeResult:
    """Compute ``M``, the trailing mean (or median) net monthly income.

    Only months that actually carry an income credit count as history: a month
    with no salary credit is treated as missing history, not as a zero-income
    month, because the latter would silently drag ``M`` — and the amortization
    threshold — down.
    """
    config = config or AmortizationConfig()
    totals = monthly_net_income(
        transactions, income_accounts=income_accounts, income_categories=income_categories
    )
    candidates = sorted(month for month, amount in totals.items() if amount > 0)
    if as_of_month is not None:
        candidates = [month for month in candidates if month <= as_of_month]

    window = config.income_window_months
    if len(candidates) < window:
        return _fallback(
            config,
            f"only {len(candidates)} month(s) of income history, need {window}",
            totals,
        )

    months_used = tuple(candidates[-window:])
    values = [totals[month] for month in months_used]

    outliers = [
        month
        for index, month in enumerate(months_used)
        if _deviates(values[index], values[:index] + values[index + 1 :], config.deviation_tolerance_pct)
    ]
    if len(values) >= 3 and outliers:
        return IncomeResult(
            monthly_income_minor=_median(values),
            method=IncomeMethod.MEDIAN,
            months_used=months_used,
            monthly_totals=tuple(sorted(totals.items())),
            reason=(
                f"{', '.join(outliers)} deviates more than "
                f"{config.deviation_tolerance_pct}% from the other months; used median"
            ),
        )

    return IncomeResult(
        monthly_income_minor=sum(values) // len(values),
        method=IncomeMethod.MEAN,
        months_used=months_used,
        monthly_totals=tuple(sorted(totals.items())),
        reason=f"mean of {len(values)} trailing month(s) of net income",
    )
