"""Sinking-fund registry and ledger (spec FR-A1, FR-A4, FR-A6).

A sinking fund is real cash set aside monthly against a planned annual expense
(Travel Fund: ₹1,20,000/yr at ₹10,000/mo). This module maps categories to funds,
accrues allocations, draws expenses down, and — critically — never resolves an
overdraw by itself: an overdraw becomes an explicit user decision.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from dataclasses import dataclass, replace
from datetime import date
from enum import StrEnum

from ..config import AlertConfig
from ..errors import BudgetError, FundOverdrawError
from ..models import Alert, AlertKind, SinkingFund, Transaction, TxnStatus
from ..money import format_inr, require_minor


class CarryOverPolicy(StrEnum):
    """What happens to an unused fund balance when the fund year rolls over.

    ``CARRY_OVER`` (the default) treats the fund as real set-aside cash: the
    unused balance stays available, so the new period's headroom is the base
    annual target plus last period's leftover. ``RESET`` starts each period at
    the plain annual target, which is what a "use it or lose it" budget wants.
    The choice is always explicit — never an accident of the rollover date.
    """

    CARRY_OVER = "carry_over"
    RESET = "reset"


class OverdrawOption(StrEnum):
    """The choices offered to the user on an overdraw (spec FR-A6)."""

    CHARGE_TO_MONTH = "charge_to_month"
    RAISE_ANNUAL_TARGET = "raise_annual_target"
    REALLOCATE_FROM_FUND = "reallocate_from_fund"


OVERDRAW_OPTIONS: tuple[OverdrawOption, ...] = tuple(OverdrawOption)


class FundNotFoundError(BudgetError):
    """No sinking fund is registered under that id."""


@dataclass(frozen=True, slots=True)
class DrawdownResult:
    """The outcome of drawing an expense against a fund.

    ``overdraw_minor`` is the part that did **not** fit. It is surfaced, never
    absorbed: the engine states the options and stops.
    """

    fund: SinkingFund
    requested_minor: int
    drawn_minor: int
    overdraw_minor: int
    balance_before_minor: int
    reason: str

    @property
    def balance_minor(self) -> int:
        return self.fund.balance_minor

    @property
    def is_overdrawn(self) -> bool:
        return self.overdraw_minor > 0

    @property
    def options(self) -> tuple[OverdrawOption, ...]:
        return OVERDRAW_OPTIONS if self.is_overdrawn else ()


@dataclass(frozen=True, slots=True)
class FundRegistry:
    """Category → fund mapping plus fund lookup by id."""

    funds: tuple[SinkingFund, ...] = ()

    def __post_init__(self) -> None:
        seen_ids: set[str] = set()
        claimed: dict[str, str] = {}
        for fund in self.funds:
            if fund.fund_id in seen_ids:
                raise BudgetError(f"duplicate fund_id: {fund.fund_id}")
            seen_ids.add(fund.fund_id)
            for category in fund.categories:
                if category in claimed:
                    raise BudgetError(
                        f"category {category!r} maps to both {claimed[category]} and {fund.fund_id}"
                    )
                claimed[category] = fund.fund_id

    @classmethod
    def from_funds(cls, funds: Iterable[SinkingFund]) -> FundRegistry:
        return cls(tuple(funds))

    @property
    def fund_ids(self) -> tuple[str, ...]:
        return tuple(fund.fund_id for fund in self.funds)

    def get(self, fund_id: str) -> SinkingFund:
        for fund in self.funds:
            if fund.fund_id == fund_id:
                return fund
        raise FundNotFoundError(f"unknown sinking fund: {fund_id!r}")

    def for_category(self, category: str) -> SinkingFund | None:
        if not category:
            return None
        for fund in self.funds:
            if category in fund.categories:
                return fund
        return None

    def for_transaction(self, txn: Transaction) -> SinkingFund | None:
        """An explicit ``sinking_fund`` on the row wins over the category map."""
        if txn.sinking_fund:
            return self.get(txn.sinking_fund)
        return self.for_category(txn.category)

    def replace_fund(self, fund: SinkingFund) -> FundRegistry:
        if all(existing.fund_id != fund.fund_id for existing in self.funds):
            raise FundNotFoundError(f"unknown sinking fund: {fund.fund_id!r}")
        return FundRegistry(
            tuple(fund if existing.fund_id == fund.fund_id else existing for existing in self.funds)
        )

    def total_drawn_minor(self) -> int:
        return sum(fund.drawn_minor for fund in self.funds)


def months_elapsed(period_start: date, as_of: date) -> int:
    """Whole months between ``period_start`` and ``as_of`` (never negative)."""
    if as_of < period_start:
        return 0
    months = (as_of.year - period_start.year) * 12 + (as_of.month - period_start.month)
    if as_of.day < period_start.day:
        months -= 1
    return max(months, 0)


def accrued_minor(fund: SinkingFund, as_of: date) -> int:
    """Allocation accrued since ``period_start``, capped at the annual target."""
    return fund.accrued_minor(months_elapsed(fund.period_start, as_of))


def available_minor(fund: SinkingFund, as_of: date | None = None) -> int:
    """Cash actually accrued and not yet drawn.

    ``balance_minor`` is headroom against the *annual* target; this is the
    stricter "money in the tin right now" figure used for reporting.
    """
    if as_of is None:
        return fund.balance_minor
    return accrued_minor(fund, as_of) - fund.drawn_minor


def _add_year(day: date) -> date:
    try:
        return day.replace(year=day.year + 1)
    except ValueError:  # 29 Feb in a non-leap year
        return day.replace(year=day.year + 1, day=28)


def periods_elapsed(fund: SinkingFund, as_of: date) -> int:
    """How many full fund years have passed since ``period_start``."""
    periods = 0
    start = fund.period_start
    while _add_year(start) <= as_of:
        start = _add_year(start)
        periods += 1
    return periods


def rollover(
    fund: SinkingFund,
    as_of: date,
    *,
    policy: CarryOverPolicy = CarryOverPolicy.CARRY_OVER,
    base_annual_target_minor: int | None = None,
) -> SinkingFund:
    """Roll the fund into the current period if its year has elapsed.

    Returns the fund unchanged when no year boundary has been crossed.
    """
    periods = periods_elapsed(fund, as_of)
    if periods == 0:
        return fund
    base_target = fund.annual_target_minor if base_annual_target_minor is None else base_annual_target_minor
    require_minor(base_target)

    start = fund.period_start
    target = fund.annual_target_minor
    drawn = fund.drawn_minor
    for _ in range(periods):
        start = _add_year(start)
        if policy is CarryOverPolicy.CARRY_OVER:
            leftover = max(target - drawn, 0)
            target = base_target + leftover
        else:
            target = base_target
        drawn = 0
    return replace(fund, period_start=start, annual_target_minor=target, drawn_minor=drawn)


def drawdown(fund: SinkingFund, amount_minor: int, *, strict: bool = False) -> DrawdownResult:
    """Draw ``amount_minor`` against ``fund``.

    Draws as much as the balance allows and reports the remainder as an
    overdraw. With ``strict=True`` an overdraw raises ``FundOverdrawError``
    instead, for callers that must not proceed without a user decision.
    """
    require_minor(amount_minor)
    if amount_minor <= 0:
        raise BudgetError("drawdown amount must be positive")
    balance_before = fund.balance_minor
    drawn = min(amount_minor, max(balance_before, 0))
    overdraw = amount_minor - drawn
    if overdraw and strict:
        raise FundOverdrawError(
            f"{fund.name}: {format_inr(amount_minor)} exceeds balance "
            f"{format_inr(balance_before)} by {format_inr(overdraw)}"
        )
    updated = replace(fund, drawn_minor=fund.drawn_minor + drawn)
    reason = (
        f"drew {format_inr(drawn)} from {fund.name}; "
        f"balance {format_inr(balance_before)} → {format_inr(updated.balance_minor)}"
    )
    if overdraw:
        reason += f"; {format_inr(overdraw)} exceeds the fund and needs a user decision"
    return DrawdownResult(
        fund=updated,
        requested_minor=amount_minor,
        drawn_minor=drawn,
        overdraw_minor=overdraw,
        balance_before_minor=balance_before,
        reason=reason,
    )


def overdraw_alert(
    result: DrawdownResult,
    *,
    month: str = "",
    category: str = "",
    alerts: AlertConfig | None = None,
) -> Alert:
    """Build the explicit ``fund_overdraw`` alert (FR-A6)."""
    if not result.is_overdrawn:
        raise BudgetError("no overdraw to report")
    alerts = alerts or AlertConfig()
    fund = result.fund
    options = ", ".join(option.value for option in result.options)
    body = (
        f"{fund.name}: {format_inr(result.requested_minor)} was charged against a balance of "
        f"{format_inr(result.balance_before_minor)}. {format_inr(result.drawn_minor)} drew the "
        f"fund; {format_inr(result.overdraw_minor)} could not. Choose one: {options}."
    )
    return Alert(
        kind=AlertKind.FUND_OVERDRAW,
        subject=f"Sinking fund overdrawn: {fund.name}",
        body=body,
        month=month,
        category=category,
        channels=alerts.routing.get("fund_overdraw", ("email",)),
    )


def apply_overdraw_decision(
    fund: SinkingFund,
    overdraw_minor: int,
    option: OverdrawOption,
    *,
    source_fund: SinkingFund | None = None,
) -> tuple[SinkingFund, SinkingFund | None]:
    """Apply the user's chosen resolution. Only ever called with an explicit choice."""
    require_minor(overdraw_minor)
    if overdraw_minor <= 0:
        raise BudgetError("overdraw_minor must be positive")
    if option is OverdrawOption.CHARGE_TO_MONTH:
        return fund, source_fund
    if option is OverdrawOption.RAISE_ANNUAL_TARGET:
        raised = replace(
            fund,
            annual_target_minor=fund.annual_target_minor + overdraw_minor,
            drawn_minor=fund.drawn_minor + overdraw_minor,
        )
        return raised, source_fund
    if source_fund is None:
        raise BudgetError("reallocation needs a source fund")
    if source_fund.balance_minor < overdraw_minor:
        raise FundOverdrawError(
            f"{source_fund.name} has only {format_inr(source_fund.balance_minor)} to reallocate"
        )
    donor = replace(
        source_fund,
        annual_target_minor=source_fund.annual_target_minor - overdraw_minor,
    )
    receiver = replace(
        fund,
        annual_target_minor=fund.annual_target_minor + overdraw_minor,
        drawn_minor=fund.drawn_minor + overdraw_minor,
    )
    return receiver, donor


def fund_drawdowns(transactions: Sequence[Transaction], fund_id: str) -> int:
    """Total amortized outflow booked against a fund (cash view, per fund)."""
    return sum(
        txn.amount_minor
        for txn in transactions
        if txn.amortized and txn.sinking_fund == fund_id and txn.status is not TxnStatus.VOID
    )
