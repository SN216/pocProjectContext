# Finance Manager — Build Plan

- Derived from: `spec/spec.md` @ commit `b1333f2`
- Intent: `intent/intent.md` @ commit `066754e` (Accepted)
- Author: Copilot CLI agent (AI-native SDLC skill) + SN (product owner)
- Status: Approved
- Date: 2026-10-16

## Approach

A **Python core tier** owns every piece of platform-independent logic: Sheets sync, the parser
rule pack, dedup, the offline queue, the enrichment contract, amortization, guardrails, SIP
reconciliation, reporting and insights. Native Android/iOS code is reduced to thin capture
adapters that marshal a platform payload into the core's `RawCapture` model and render prompts.

This split is deliberate. The Android SDK and Xcode are unavailable in the build environment, so
native code cannot be built or tested here (hard rule 3: verify before review). Keeping the logic
in the core means the capture, ingestion, amortization and sync behaviour is **verified**, while
only the platform shells are deferred and explicitly reported as unverified.

Money is integer minor units (paise) end to end; `money.py` rejects floats at the boundary.

## Decisions taken during Build (amending spec.md)

| Decision | Effect |
|---|---|
| Core language: **Python** | Matches the existing `scripts/` tooling; builds and tests in this environment. |
| Scope: core fully built and tested, native adapters scaffolded only | Modules 2 and 3 split into verified core logic plus a deferred platform shell. |
| iOS degraded tier **accepted** (spec G1/Q1) | iOS = Shortcuts + share sheet + email-forward. Android parity is not achievable. |
| Sheet columns **auto-detected and mapped** (spec Q3) | **Spec amendment.** The fixed A–P managed range in spec §2 is replaced by header introspection plus a mapping layer that creates only missing agent-owned columns. |
| Budgets live **in the Sheet** (`Budgets` tab) (spec Q6) | The budget engine reads limits from Sheets, preserving a single source of truth. |
| **Core worker yes**, runnable locally (spec Q8) | Scheduler and email ingest exist as a locally runnable process; hosting is deferred. |
| **All 8 proposed extras enter v1** (spec Q11) | Staged as Wave 2 so the core gates are not blocked by insight features. |
| Rule packs are **JSON, not YAML** | Deviation from the original plan: PyYAML has no wheel for Python 3.15 here, and JSON keeps the core dependency-free. Rules remain versioned *data*, which is the property that mattered. |
| A **`make.ps1` shim** accompanies the Makefile | This platform has no `make`; the documented verification commands must actually be runnable. |

## Waves

- **Wave 1 — core spine:** toolchain, foundations, Sheets layer, parser + dedup, offline queue,
  iOS ingest + enrichment, amortization + guardrails, SIP/alerts/worker.
- **Wave 2 — the eight approved extras:** recurring detection, payday sweep, card cycles,
  forecast, trip grouping, refunds, Sheet-edit reconciliation, annual review. These read the
  ledger projection only and cannot modify capture or sync.
- **Wave 3 — native adapter scaffolds:** Kotlin and Swift marshalling shells, explicitly
  unverifiable in this environment.

## Files that change

Toolchain and artifacts:

- `my-new-project/Makefile`
- `my-new-project/make.ps1`
- `my-new-project/pyproject.toml`
- `my-new-project/plan/plan.md`
- `my-new-project/CLAUDE.md`
- `my-new-project/spec/spec.md`

Foundations (frozen after Wave 1 step 2):

- `my-new-project/src/finance_manager/__init__.py`
- `my-new-project/src/finance_manager/money.py`
- `my-new-project/src/finance_manager/ids.py`
- `my-new-project/src/finance_manager/models.py`
- `my-new-project/src/finance_manager/errors.py`
- `my-new-project/src/finance_manager/config.py`

Module 1 — Google Sheets:

- `my-new-project/src/finance_manager/sheets/__init__.py`
- `my-new-project/src/finance_manager/sheets/auth.py`
- `my-new-project/src/finance_manager/sheets/backoff.py`
- `my-new-project/src/finance_manager/sheets/client.py`
- `my-new-project/src/finance_manager/sheets/schema.py`
- `my-new-project/src/finance_manager/sheets/repository.py`

Module 2 — capture, parser rule pack, dedup, queue:

- `my-new-project/src/finance_manager/capture/__init__.py`
- `my-new-project/src/finance_manager/capture/ruleset.py`
- `my-new-project/src/finance_manager/capture/parser.py`
- `my-new-project/src/finance_manager/capture/dedup.py`
- `my-new-project/src/finance_manager/capture/sources.py`
- `my-new-project/src/finance_manager/capture/queue.py`
- `my-new-project/src/finance_manager/capture/rules/*.json`

Module 3 — iOS ingestion and enrichment:

- `my-new-project/src/finance_manager/capture/ios_ingest.py`
- `my-new-project/src/finance_manager/capture/email_ingest.py`
- `my-new-project/src/finance_manager/enrichment/__init__.py`
- `my-new-project/src/finance_manager/enrichment/prompt.py`
- `my-new-project/src/finance_manager/enrichment/memory.py`

Module 4 — budgets and amortization:

- `my-new-project/src/finance_manager/budget/__init__.py`
- `my-new-project/src/finance_manager/budget/income.py`
- `my-new-project/src/finance_manager/budget/sinking_funds.py`
- `my-new-project/src/finance_manager/budget/amortization.py`
- `my-new-project/src/finance_manager/budget/guardrails.py`

SIP, alerts, worker:

- `my-new-project/src/finance_manager/sip/__init__.py`
- `my-new-project/src/finance_manager/sip/reconciler.py`
- `my-new-project/src/finance_manager/alerts/__init__.py`
- `my-new-project/src/finance_manager/alerts/dispatcher.py`
- `my-new-project/src/finance_manager/worker/__init__.py`
- `my-new-project/src/finance_manager/worker/scheduler.py`

Wave 2 — insights:

- `my-new-project/src/finance_manager/insights/*.py`

Wave 3 — native adapters (not buildable here):

- `my-new-project/adapters/README.md`
- `my-new-project/adapters/android/*.kt`
- `my-new-project/adapters/android/README.md`
- `my-new-project/adapters/ios/*.swift`
- `my-new-project/adapters/ios/README.md`

Tests and evals:

- `my-new-project/tests/*.py`
- `my-new-project/tests/fakes/fake_sheets.py`
- `my-new-project/tests/fixtures/messages/*.json`
- `my-new-project/evals/parse-cases.json`
- `my-new-project/evals/dedup-cases.json`
- `my-new-project/evals/amortize-cases.json`

## Order of work

1. **Toolchain.** `pyproject.toml`, `Makefile` + `make.ps1` with targets matching `CLAUDE.md`;
   `make build` ends with "Build succeeded".
2. **Foundations.** `money.py`, `ids.py`, `models.py`, `errors.py`, `config.py`. Frozen on commit
   so the module work can parallelize safely.
3. **Module 1 — Sheets.** `backoff.py` → `schema.py` (header auto-detection) → `client.py`
   (batched writes) → `auth.py` (OAuth, keyring) → `repository.py` (idempotent upsert,
   Sheet-wins reconcile). Tested against an in-memory fake; no network in tests.
4. **Module 2 — parser + dedup.** Redaction gate first, then the JSON rule packs, the parser, and
   the dedup rules with both failure directions tested.
5. **Module 2b — queue.** SQLite WAL offline queue with leases and crash recovery.
6. **Module 3 — ingestion + enrichment.** iOS Shortcut/share-sheet ingest, verified email ingest,
   the platform-neutral enrichment state machine, and merchant→category memory.
7. **Module 4 — amortization.** Trailing-mean income, sinking funds, the 1/5th decision flow, and
   guardrails that exclude amortized rows.
8. **Invariant tests.** The spec's worked example, the threshold boundaries, and the
   cash-vs-amortized reconciliation.
9. **SIP, alerts, worker.** ±3-day matching, alert routing and caps, locally runnable jobs.
10. **Wave 2.** The eight approved extras, each with its own tests.
11. **Wave 3.** Kotlin and Swift adapter scaffolds with READMEs stating permissions, build
    commands, and that they are not buildable here.
12. **Evals and artifacts.** Populate `evals/*.json`, update `CLAUDE.md`, amend `spec/spec.md`.

## Risks

| Risk | De-risk |
|---|---|
| **Column auto-detection is new, unspecified design.** Fuzzy header matching could silently map to the wrong column and corrupt a real ledger. | Mapping is explicit and reported; ambiguity **raises** instead of guessing; the agent never writes to a column it did not map or create; a dry-run mapping report precedes the first write. |
| All eight extras in v1 inflates scope. | Strict waves; Wave 1 must be fully green first; extras are read-only over the ledger projection. |
| Dedup is the top correctness risk (spec G4). | Both failure directions tested and seeded as evals; ambiguous matches surface in the prompt instead of auto-merging. |
| Parser rules drift as banks reword messages (spec G3). | Rules are versioned data; unparsed input becomes `needs_review` and surfaces in the daily digest within 24 h. |
| Amortization could hide genuine overspending (spec G5). | The engine only *proposes*; amortization requires a mapped fund plus explicit confirmation, and reports always show the cash view too. |
| Real Google credentials reaching git. | No credential files in the repo; keyring/env-only secrets; `scan_secrets.py` before every commit; tests use a fake transport. |
| Native adapters cannot be verified here (hard rule 3). | They contain marshalling only; each is labelled unverified and the Build gate evidence states this explicitly. |
| Float money creeping in. | `money.py` raises on float input; tests assert the invariant. |

## Proof

- `tests/test_amortization.py` — the spec's worked example (M=₹1L, ₹1L trip, ₹20k balance, no
  March overrun) and the three `M/5` boundaries.
- `tests/test_sinking_funds.py` — cash-view total equals amortized-view total over a fund year.
- `tests/test_dedup.py` — one payment from three sources collapses to one row; two genuine ₹200
  payments three minutes apart remain two rows.
- `tests/test_redaction.py` — OTP/PIN/PAN text never reaches the parser or the ledger.
- `tests/test_sheets_repository.py` — a repeated sync creates zero duplicates; a manual Sheet edit
  wins on reconcile.
- `tests/test_sheets_schema.py` — auto-detection maps a realistic header row and raises on an
  ambiguous one.
- `tests/test_queue.py` — no loss or duplication across offline→online, including crash recovery.
- `evals/*.json` executed by `scripts/run_evals.py` supply the Phase-4 pass rate.

No screenshots: this wave has no UI.

## Verification

```
cd my-new-project
.\make.ps1 build      # or: make build   -> ends with "Build succeeded"
.\make.ps1 lint       # ruff check + format --check, zero warnings
.\make.ps1 test       # pytest, all green
.\make.ps1 evals      # pass rate above the configured minimum
python ..\skills\ai-native-sdlc\scripts\scan_secrets.py --staged   # 0 finding(s)
```

Native adapter sources are excluded from build, lint and test, and are reported as unverified in
the Build gate evidence.

## Parallelization

After foundations are frozen and committed, `sheets/`, `capture/` and `budget/` touch disjoint
packages and share only `models.py`/`money.py`, so they run as isolated named sessions:

- `sheets-module` — the Google Sheets auth, schema-detection and sync layer.
- `parser-module` — the redaction gate, JSON rule packs, parser and dedup.
- `queue-module` — the durable offline capture queue.
- `amortization-module` — income, sinking funds, the 1/5th rule and guardrails.

Wave 2's eight insight modules are mutually independent and read-only over the ledger, so they
parallelize cleanly. Each session has a functional name, a bounded file scope taken from the list
above, and reports back with test evidence; none commits, so the artifact chain stays linear and
auditable (hard rule 8).

## Gate

Nothing in this plan crosses the production gate: no deploy, no release, no live Google API call,
and no real credentials. The Build gate closes with the verification evidence above plus an
explicit statement of what was *not* verified (the native adapters).
